#SXD20|20010|50529|50410|2013.11.01 03:35:51|olimp|0|33|498|
#TA AuthAssignment`4`16384|AuthItem`36`16384|AuthItemChild`32`16384|Rights`36`16384|tbl_category`2`16384|tbl_country`14`16384|tbl_event`5`16384|tbl_event_country`2`16384|tbl_image`4`16384|tbl_item`66`16384|tbl_menu`3`16384|tbl_menu_item`28`16384|tbl_migration`0`16384|tbl_organization`0`16384|tbl_organization_fav`0`16384|tbl_organization_group`11`16384|tbl_organization_region`7`16384|tbl_organization_type`6`16384|tbl_place`7`49152|tbl_placegroup`2`16384|tbl_profiles`2`16384|tbl_profiles_fields`46`16384|tbl_sport`24`16384|tbl_sportgroup`2`16384|tbl_sporttext`138`180224|tbl_tag`3`16384|tbl_task`1`16384|tbl_task_comment`1`16384|tbl_task_fav`0`16384|tbl_task_prior`5`16384|tbl_task_stage`7`16384|tbl_task_type`2`16384|tbl_users`2`16384
#EOH

#	TC`AuthAssignment`utf8_general_ci	;
CREATE TABLE `AuthAssignment` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `userid` varchar(64) CHARACTER SET latin1 NOT NULL,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`itemname`,`userid`),
  CONSTRAINT `AuthAssignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthAssignment`utf8_general_ci	;
INSERT INTO `AuthAssignment` VALUES 
('Admin','1',\N,'N;'),
('Authenticated','2',\N,'N;'),
('Authenticated','3',\N,'N;'),
('Authenticated','5',\N,'N;')	;
#	TC`AuthItem`utf8_general_ci	;
CREATE TABLE `AuthItem` (
  `name` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET latin1,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItem`utf8_general_ci	;
INSERT INTO `AuthItem` VALUES 
('Admin',2,'Administrator',\N,'N;'),
('Authenticated',2,'Registered user',\N,'N;'),
('Guest',2,'Guest',\N,'N;'),
('user.*',1,'user.*',\N,'N;'),
('user.activation.*',1,'user.activation.*',\N,'N;'),
('user.activation.activation',0,'user.activation.activation',\N,'N;'),
('user.admin.*',1,'user.admin.*',\N,'N;'),
('user.admin.admin',0,'user.admin.admin',\N,'N;'),
('user.admin.create',0,'user.admin.create',\N,'N;'),
('user.admin.delete',0,'user.admin.delete',\N,'N;'),
('user.admin.update',0,'user.admin.update',\N,'N;'),
('user.admin.view',0,'user.admin.view',\N,'N;'),
('user.authorized',1,'user.authorized',\N,'N;'),
('user.default.*',1,'user.default.*',\N,'N;'),
('user.default.index',0,'user.default.index',\N,'N;'),
('user.login.*',1,'user.login.*',\N,'N;'),
('user.login.login',0,'user.login.login',\N,'N;'),
('user.logout.*',1,'user.logout.*',\N,'N;'),
('user.logout.logout',0,'user.logout.logout',\N,'N;'),
('user.not_authorized',1,'user.not_authorized',\N,'N;'),
('user.profile.*',1,'user.profile.*',\N,'N;'),
('user.profile.changepassword',0,'user.profile.changepassword',\N,'N;'),
('user.profile.edit',0,'user.profile.edit',\N,'N;'),
('user.profile.profile',0,'user.profile.profile',\N,'N;'),
('user.profilefield.*',1,'user.profilefield.*',\N,'N;'),
('user.profilefield.admin',0,'user.profilefield.admin',\N,'N;'),
('user.profilefield.create',0,'user.profilefield.create',\N,'N;'),
('user.profilefield.delete',0,'user.profilefield.delete',\N,'N;'),
('user.profilefield.update',0,'user.profilefield.update',\N,'N;'),
('user.recovery.*',1,'user.recovery.*',\N,'N;'),
('user.recovery.recovery',0,'user.recovery.recovery',\N,'N;'),
('user.registration.*',1,'user.registration.*',\N,'N;'),
('user.registration.registration',0,'user.registration.registration',\N,'N;'),
('user.user.*',1,'user.user.*',\N,'N;'),
('user.user.index',0,'user.user.index',\N,'N;'),
('user.user.view',0,'user.user.view',\N,'N;')	;
#	TC`AuthItemChild`utf8_general_ci	;
CREATE TABLE `AuthItemChild` (
  `parent` varchar(64) CHARACTER SET latin1 NOT NULL,
  `child` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `AuthItemChild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuthItemChild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItemChild`utf8_general_ci	;
INSERT INTO `AuthItemChild` VALUES 
('user.not_authorized','user.activation.*'),
('user.activation.*','user.activation.activation'),
('user.*','user.admin.*'),
('user.admin.*','user.admin.admin'),
('user.admin.*','user.admin.create'),
('user.admin.*','user.admin.delete'),
('user.admin.*','user.admin.update'),
('user.admin.*','user.admin.view'),
('Authenticated','user.authorized'),
('user.authorized','user.default.*'),
('user.default.*','user.default.index'),
('user.not_authorized','user.login.*'),
('user.login.*','user.login.login'),
('user.authorized','user.logout.*'),
('user.logout.*','user.logout.logout'),
('Guest','user.not_authorized'),
('user.authorized','user.profile.*'),
('user.profile.*','user.profile.changepassword'),
('user.profile.*','user.profile.edit'),
('user.profile.*','user.profile.profile'),
('user.*','user.profilefield.*'),
('user.profilefield.*','user.profilefield.admin'),
('user.profilefield.*','user.profilefield.create'),
('user.profilefield.*','user.profilefield.delete'),
('user.profilefield.*','user.profilefield.update'),
('user.not_authorized','user.recovery.*'),
('user.recovery.*','user.recovery.recovery'),
('user.not_authorized','user.registration.*'),
('user.registration.*','user.registration.registration'),
('user.authorized','user.user.*'),
('user.user.*','user.user.index'),
('user.user.*','user.user.view')	;
#	TC`Rights`utf8_general_ci	;
CREATE TABLE `Rights` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`),
  CONSTRAINT `Rights_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`Rights`utf8_general_ci	;
INSERT INTO `Rights` VALUES 
('Admin',2,0),
('Authenticated',2,1),
('Guest',2,2),
('user.*',1,72),
('user.activation.*',1,73),
('user.activation.activation',0,213),
('user.admin.*',1,74),
('user.admin.admin',0,214),
('user.admin.create',0,215),
('user.admin.delete',0,216),
('user.admin.update',0,217),
('user.admin.view',0,218),
('user.authorized',1,75),
('user.default.*',1,76),
('user.default.index',0,219),
('user.login.*',1,77),
('user.login.login',0,220),
('user.logout.*',1,78),
('user.logout.logout',0,221),
('user.not_authorized',1,79),
('user.profile.*',1,80),
('user.profile.changepassword',0,222),
('user.profile.edit',0,223),
('user.profile.profile',0,224),
('user.profilefield.*',1,81),
('user.profilefield.admin',0,225),
('user.profilefield.create',0,226),
('user.profilefield.delete',0,227),
('user.profilefield.update',0,228),
('user.recovery.*',1,82),
('user.recovery.recovery',0,229),
('user.registration.*',1,83),
('user.registration.registration',0,230),
('user.user.*',1,84),
('user.user.index',0,231),
('user.user.view',0,232)	;
#	TC`tbl_category`utf8_general_ci	;
CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `value` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `visible` (`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_category`utf8_general_ci	;
INSERT INTO `tbl_category` VALUES 
(1,'news',1,'Новости',''),
(2,'medals',1,'Медали','')	;
#	TC`tbl_country`utf8_general_ci	;
CREATE TABLE `tbl_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8	;
#	TD`tbl_country`utf8_general_ci	;
INSERT INTO `tbl_country` VALUES 
(1,'Чехия',\N),
(2,'Швеция',\N),
(3,'Финляндия',\N),
(4,'Австрия',\N),
(5,'Россия',\N),
(6,'Словения',\N),
(7,'Канада',\N),
(8,'Норвегия',\N),
(9,'Латвия',\N),
(10,'Швейцария',\N),
(11,'Словакия',''),
(12,'США',''),
(13,'Япония',''),
(14,'Германия','')	;
#	TC`tbl_event`utf8_general_ci	;
CREATE TABLE `tbl_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `medal` tinyint(1) DEFAULT NULL,
  `sex` set('male','female') DEFAULT NULL,
  `datetime1` datetime DEFAULT NULL,
  `datetime2` datetime DEFAULT NULL,
  `short_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sport_id` (`sport_id`),
  KEY `place_id` (`place_id`),
  KEY `sex` (`sex`),
  CONSTRAINT `tbl_event_ibfk_1` FOREIGN KEY (`sport_id`) REFERENCES `tbl_sport` (`id`),
  CONSTRAINT `tbl_event_ibfk_2` FOREIGN KEY (`place_id`) REFERENCES `tbl_place` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_event`utf8_general_ci	;
INSERT INTO `tbl_event` VALUES 
(1,1,21,\N,\N,'2014-02-07 20:00:00','2014-02-07 23:00:00',\N,\N),
(2,1,23,\N,\N,'2014-02-23 20:00:00','2014-02-07 22:30:00',\N,\N),
(3,1,22,\N,\N,'2014-03-07 20:00:00',\N,\N,\N),
(4,1,24,\N,\N,'2014-03-16 20:00:00',\N,\N,\N),
(5,2,9,\N,'male','2014-02-12 21:00:00','2014-02-12 23:30:00','Чехия - Швеция',\N)	;
#	TC`tbl_event_country`utf8_general_ci	;
CREATE TABLE `tbl_event_country` (
  `event_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  UNIQUE KEY `event_id` (`event_id`,`country_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `tbl_event_country_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `tbl_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_event_country_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `tbl_country` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`tbl_event_country`utf8_general_ci	;
INSERT INTO `tbl_event_country` VALUES 
(5,1),
(5,2)	;
#	TC`tbl_image`utf8_general_ci	;
CREATE TABLE `tbl_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cron` tinyint(1) DEFAULT '0',
  `image_url` varchar(255) NOT NULL,
  `prior` int(11) DEFAULT NULL,
  `preview` tinyint(1) DEFAULT '0',
  `visible` tinyint(1) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visible` (`visible`),
  KEY `prior` (`prior`),
  KEY `preview` (`preview`),
  KEY `cron` (`cron`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`tbl_image`utf8_general_ci	;
INSERT INTO `tbl_image` VALUES 
(1,0,'http://upload.wikimedia.org/wikipedia/en/8/8a/SochiOlympicsStadium.jpg',\N,0,0,\N,'place','central-stadium'),
(2,0,'http://pixelsport.ru/wp-content/uploads/2013/03/149.jpg',\N,0,0,\N,'place','central-stadium'),
(3,0,'http://pixelsport.ru/wp-content/uploads/2013/03/235.jpg',\N,0,0,\N,'place','central-stadium'),
(4,0,'http://upload.wikimedia.org/wikipedia/en/8/8a/SochiOlympicsStadium.jpg',\N,0,0,\N,'place','central-stadium')	;
#	TC`tbl_item`utf8_general_ci	;
CREATE TABLE `tbl_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL,
  `controller` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `h1` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_2` (`module`,`controller`,`action`),
  KEY `parent_id` (`parent_id`),
  KEY `controller` (`controller`),
  KEY `action` (`action`),
  KEY `module` (`module`),
  KEY `icon` (`icon`),
  KEY `url` (`url`),
  CONSTRAINT `tbl_item_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `tbl_item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8	;
#	TD`tbl_item`utf8_general_ci	;
INSERT INTO `tbl_item` VALUES 
(1,\N,'admin','default','index','/admin/','icon-home','Admin','Admin','Admin',''),
(2,1,'admin','organization','index','','icon-list','Организации','Организации','Организации','это компании или корпоративные отделы, с которыми вы имеете деловые отношения'),
(3,1,'bugtracker','default','index','','icon-tasks','Задачи','Задачи','Задачи','перечень или реестр задач, событий и звонков, связанных с записями CRM, относящимися к различным модулям'),
(5,1,'admin','glossary','index','','icon-list-alt','Справочники','Справочники','Справочники','списки данных, используемые в различных таблицах'),
(6,1,'user','profile','profile','/user/profile','icon-user','Профиль пользователя','Профиль пользователя','Профиль',''),
(11,2,'admin','organization','create','','icon-plus','Создать Организацию','Создать Организацию','Создать',''),
(13,3,'bugtracker','default','create','','icon-plus','Создать Задачу','Создать Задачу','Создать',''),
(17,3,'bugtracker','tasktype','index','','icon-tags','Типы задач','Типы задач','Типы задач','виды задач, определяющие что именно нужно сделать'),
(18,2,'admin','organizationtype','index','','icon-tags','Типы организаций','Типы организаций','Типы организаций','например: заказчик, поставщик, партнер'),
(19,2,'admin','organizationregion','index','','icon-globe','Регионы организаций','Регионы организаций','Регионы организаций','страны, области или города'),
(20,2,'admin','organizationgroup','index','','icon-tags','Группы организаций','Группы организаций','Группы организаций',''),
(23,6,'user','logout','logout','/user/logout','icon-off','Выйти','Выйти','Выйти',''),
(40,2,'admin','organization','view','','icon-eye-open','Организация','Организация','Просмотр',''),
(41,40,'admin','organization','update','','icon-pencil','Редактировать Организацию','Редактировать Организацию','Редактировать',''),
(50,3,'bugtracker','default','view','','icon-eye-open','Задача','Задача','Просмотр',''),
(51,50,'bugtracker','default','update','','icon-pencil','Редактировать Задачу','Редактировать Задачу','Редактировать',''),
(57,20,'admin','organizationgroup','create','','icon-plus','Создать Группу Организаций','Создать Группу Организаций','Создать',''),
(58,20,'admin','organizationgroup','view','','icon-eye-open','Группа Организаций','Группа Организаций','Просмотр',''),
(59,58,'admin','organizationgroup','update','','icon-pencil','Редактировать Группу Организаций','Редактировать Группу Организаций','Редактировать',''),
(61,19,'admin','organizationregion','view','','icon-eye-open','Регион Организаций','Регион Организаций','Просмотр',''),
(62,19,'admin','organizationregion','create','','icon-plus','Создать Регион Организаций','Создать Регион Организаций','Создать',''),
(63,61,'admin','organizationregion','update','','icon-pencil','Редактировать Регион Организаций','Редактировать Регион Организаций','Редактировать',''),
(65,18,'admin','organizationtype','create','','icon-plus','Создать Тип Организаций','Создать Тип Организаций','Создать',''),
(66,18,'admin','organizationtype','view','','icon-eye-open','Тип Организаций','Тип Организаций','Просмотр',''),
(67,66,'admin','organizationtype','update','','icon-pencil','Редактировать Тип Организаций','Редактировать Тип Организаций','Редактировать',''),
(69,17,'bugtracker','tasktype','create','','icon-plus','Создать Тип Задач','Создать Тип Задач','Создать',''),
(70,17,'bugtracker','tasktype','view','','icon-eye-open','Тип Задач','Тип Задач','Просмотр',''),
(71,70,'bugtracker','tasktype','update','','icon-pencil','Редактировать Тип Задач','Редактировать Тип Задач','Редактировать',''),
(73,5,'admin','item','index','','icon-th','Пункты','Пункты','Пункты',''),
(74,73,'admin','item','create','','icon-plus','Создать Пункт','Создать Пункт','Создать',''),
(75,73,'admin','item','view','','icon-eye-open','Пункт','Пункт','Просмотр',''),
(76,75,'admin','item','update','','icon-pencil','Редактировать Пункт','Редактировать Пункт','Редактировать',''),
(79,5,'admin','menu','index','','icon-th-large','Меню','Меню','Меню',''),
(80,79,'admin','menu','create','','icon-plus','Создать Меню','Создать Меню','Создать',''),
(81,79,'admin','menu','view','','icon-eye-open','Просмотр Меню','Просмотр Меню','Просмотр',''),
(82,81,'admin','menu','update','','icon-pencil','Редактировать Меню','Редактировать Меню','Редактировать',''),
(84,5,'admin','menuitem','index','','icon-th-list','Пункты меню','Пункты меню','Пункты меню',''),
(85,84,'admin','menuitem','create','','icon-plus','Создать Пункт Меню','Создать Пункт Меню','Создать',''),
(86,84,'admin','menuitem','view','','icon-eye-open','Пункт Меню','Пункт Меню','Просмотр',''),
(87,86,'admin','menuitem','update','','icon-pencil','Редактировать Пункт Меню','Редактировать Пункт Меню','Редактировать',''),
(99,5,'','sxd','index','/sxd/','','Дампы БД','Дампы БД','Дампы БД',''),
(100,5,'rights','assignment','view','/rights/','icon-eye-open','Rights','Rights','Rights',''),
(120,3,'bugtracker','taskprior','index','','icon-signal','Приоритеты Задач','Приоритеты Задач','Приоритеты Задач',''),
(121,3,'bugtracker','taskstage','index','','icon-signal','Этапы Задач','Этапы Задач','Этапы Задач','К  номерам этапов задач жестко привязаны действия с задачами. Менять можно приоритет и название, но смысл названия должен быть близок к исходному.'),
(122,121,'bugtracker','taskstage','create','','icon-plus','Создать Этап Задач','Создать Этап Задач','Создать',''),
(124,121,'bugtracker','taskstage','view','','icon-eye-open','Этап Задач','Этап Задач','Просмотр',''),
(125,124,'bugtracker','taskstage','update','','icon-pencil','Редактировать Этап Задач','Редактировать Этап Задач','Редактировать',''),
(126,120,'bugtracker','taskprior','create','','icon-plus','Создать Приоритет Задач','Создать Приоритет Задач','Создать',''),
(127,120,'bugtracker','taskprior','view','','icon-eye-open','Приоритет Задач','Приоритет Задач','Просмотр',''),
(129,127,'bugtracker','taskprior','update','','icon-pencil','Редактировать Приоритет Задач','Редактировать Приоритет Задач','Редактировать',''),
(132,2,'admin','organization','favorite','','icon-star','Избранные Организации','Избранные Организации','Избранные',''),
(133,3,'bugtracker','default','favorite','','icon-star','Избранные Задачи','Избранные Задачи','Избранные',''),
(156,\N,'user','login','login','/user/login','icon-forward','Войти','Войти','Войти',''),
(157,\N,'user','registration','registration','/user/registration','icon-plus-sign','Зарегистрироваться','Зарегистрироваться','Зарегистрироваться',''),
(256,5,'admin','country','index','','','Страны','Страны','Страны',''),
(257,256,'admin','country','view','','','Страна','Страна','Страна',''),
(258,256,'admin','country','create','','','Добавить Страну','Добавить Страну','Добавить страну',''),
(259,257,'admin','country','update','','','Редактировать страну','Редактировать страну','Редактировать страну',''),
(260,5,'admin','placegroup','index','','','Группы мест проведения','Группы мест проведения','Группы мест проведения',''),
(261,260,'admin','placegroup','view','','','Группа мест проведения','Группа мест проведения','Группа мест проведения',''),
(262,260,'admin','placegroup','create','','','Добавить группу мест проведения','Добавить группу мест проведения','Добавить группу мест проведения',''),
(263,261,'admin','placegroup','update','','','Редактировать группу мест проведения','Редактировать группу мест проведения','Редактировать группу мест проведения',''),
(264,5,'admin','place','index','','','Места проведения','Места проведения','Места проведения',''),
(265,264,'admin','place','view','','','Место проведения','Место проведения','Место проведения',''),
(266,265,'admin','place','update','','','Редактировать Место проведения','Редактировать Место проведения','Редактировать',''),
(267,264,'admin','place','create','','','Создать Место проведения','Создать Место проведения','Создать','')	;
#	TC`tbl_menu`utf8_general_ci	;
CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(64) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `name` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_menu`utf8_general_ci	;
INSERT INTO `tbl_menu` VALUES 
(1,'top_menu','Верхнее меню'),
(2,'bottom_menu','Нижнее меню'),
(3,'site_menu','Меню сайта')	;
#	TC`tbl_menu_item`utf8_general_ci	;
CREATE TABLE `tbl_menu_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `item_id` int(11) NOT NULL,
  `prior` tinyint(4) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `guest_only` tinyint(1) NOT NULL DEFAULT '0',
  `value` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `visible` (`visible`),
  KEY `prior` (`prior`),
  KEY `parent_id` (`parent_id`),
  KEY `menu_id` (`menu_id`),
  KEY `item_id` (`item_id`),
  KEY `guest_only` (`guest_only`),
  CONSTRAINT `tbl_menu_item_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `tbl_menu_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_menu_item_ibfk_4` FOREIGN KEY (`menu_id`) REFERENCES `tbl_menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_menu_item_ibfk_5` FOREIGN KEY (`item_id`) REFERENCES `tbl_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8	;
#	TD`tbl_menu_item`utf8_general_ci	;
INSERT INTO `tbl_menu_item` VALUES 
(2,1,\N,2,2,1,0,'',''),
(3,1,\N,3,3,1,0,'',''),
(5,1,\N,5,5,1,0,'',''),
(6,1,\N,6,6,1,0,'',''),
(45,1,2,132,1,1,0,\N,\N),
(46,1,2,2,2,1,0,\N,\N),
(48,1,5,18,30,1,0,\N,\N),
(49,1,5,20,30,1,0,\N,\N),
(50,1,5,19,30,1,0,\N,\N),
(51,1,2,11,8,1,0,\N,\N),
(52,1,3,133,1,1,0,\N,\N),
(53,1,3,3,2,1,0,\N,\N),
(54,1,5,17,20,1,0,\N,\N),
(55,1,5,121,50,1,0,\N,\N),
(56,1,5,120,50,1,0,\N,\N),
(57,1,3,13,9,1,0,\N,\N),
(70,1,6,99,3,1,0,\N,\N),
(71,1,6,100,4,1,0,\N,\N),
(72,1,6,6,1,1,0,\N,\N),
(73,1,6,23,2,1,0,\N,\N),
(74,1,\N,156,10,1,1,\N,\N),
(75,1,\N,157,11,1,1,\N,\N),
(87,1,5,79,10,1,0,\N,\N),
(88,1,5,73,10,1,0,\N,\N),
(90,1,5,84,10,1,0,\N,\N),
(98,1,5,256,1,1,0,\N,\N),
(99,1,5,260,1,1,0,\N,\N),
(103,1,\N,264,1,1,0,\N,\N)	;
#	TC`tbl_migration`utf8_general_ci	;
CREATE TABLE `tbl_migration` (
  `version` varchar(255) CHARACTER SET latin1 NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_organization`utf8_general_ci	;
CREATE TABLE `tbl_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization_type_id` int(11) NOT NULL,
  `organization_group_id` int(11) NOT NULL,
  `organization_region_id` int(11) NOT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `organization_type_id` (`organization_type_id`),
  KEY `organization_group_id` (`organization_group_id`),
  KEY `organization_region_id` (`organization_region_id`),
  CONSTRAINT `tbl_organization_ibfk_7` FOREIGN KEY (`organization_type_id`) REFERENCES `tbl_organization_type` (`id`),
  CONSTRAINT `tbl_organization_ibfk_8` FOREIGN KEY (`organization_group_id`) REFERENCES `tbl_organization_group` (`id`),
  CONSTRAINT `tbl_organization_ibfk_9` FOREIGN KEY (`organization_region_id`) REFERENCES `tbl_organization_region` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_organization_fav`utf8_general_ci	;
CREATE TABLE `tbl_organization_fav` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `datetime` int(11) DEFAULT NULL,
  UNIQUE KEY `id_2` (`id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `id` (`id`),
  CONSTRAINT `tbl_organization_fav_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_organization_fav_ibfk_3` FOREIGN KEY (`id`) REFERENCES `tbl_organization` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_organization_group`utf8_general_ci	;
CREATE TABLE `tbl_organization_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_group`utf8_general_ci	;
INSERT INTO `tbl_organization_group` VALUES 
(1,'Прочие организации',''),
(2,'Юридические организации',''),
(3,'ИТ-компании',''),
(4,'Банки/финансовые организации',''),
(5,'Розничная торговля',''),
(6,'Гостиницы/рестораны',''),
(7,'Промышленность/производство',''),
(8,'Медицина',''),
(9,'Государственный сектор',''),
(10,'Услуги',''),
(11,'Транспорт','')	;
#	TC`tbl_organization_region`utf8_general_ci	;
CREATE TABLE `tbl_organization_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_region`utf8_general_ci	;
INSERT INTO `tbl_organization_region` VALUES 
(1,'Россия',''),
(2,'Зарубежье',''),
(3,'Украина',''),
(4,'Иран',''),
(5,'Италия',''),
(6,'Швеция',''),
(7,'Германия','')	;
#	TC`tbl_organization_type`utf8_general_ci	;
CREATE TABLE `tbl_organization_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_type`utf8_general_ci	;
INSERT INTO `tbl_organization_type` VALUES 
(1,'Партнер',''),
(2,'Заказчик',''),
(3,'Поставщик',''),
(4,'Предполагаемый заказчик',''),
(5,'Потерянный заказчик',''),
(6,'Конкурент','')	;
#	TC`tbl_place`utf8_general_ci	;
CREATE TABLE `tbl_place` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `placegroup_id` int(11) NOT NULL,
  `prior` int(11) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `mest` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `use_after` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `description1` text,
  PRIMARY KEY (`id`),
  KEY `prior` (`prior`),
  KEY `placegroup_id` (`placegroup_id`),
  KEY `visible` (`visible`),
  CONSTRAINT `tbl_place_ibfk_1` FOREIGN KEY (`placegroup_id`) REFERENCES `tbl_placegroup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`tbl_place`utf8_general_ci	;
INSERT INTO `tbl_place` VALUES 
(1,1,1,1,'central-stadium','40000','2013','Футбольный стадион, многофункциональный спортивный и развлекательный центр','\"Фишт\"','Олимпийский стадион \"Фишт\"','Здание Олимпийского Стадиона «Фишт» расположено в Олимпийском парке так, что зрители на трибунах могут одновременно наблюдать горные вершины на севере и море на юге.\n\nКомпозиция Олимпийского Стадиона «Фишт» в Сочи абсолютно уникальна для России. Кровля стадиона будет выполнена из долговечного светопропускающего плёночного материала, используемого во многих стадионах, и при взгляде в сторону гор, стадион напомнит форму скалистого утёса, который гармонично вольется в открывающуюся из Имеретинской низменности панораму Кавказских гор.\n\nПриоритетом при проектировании является обеспечение максимальной безопасности зрителей, спортсменов, сотрудников. Важная цель - минимизация степени экологических рисков и возможного экологического ущерба при строительстве и эксплуатации проектируемого здания. Проектирование стадиона было проведено, в том числе, с учетом полного соблюдения требований Международного паралимпийского комитета и с использованием лучшей международной практики по организации доступной среды для людей с инвалидностью.\n\nПо окончании Олимпийских и Паралимпийских игр 2014 года Олимпийский Стадион «Фишт» станет местом проведения матчей национальной сборной России по футболу, тренировочным спортивным центром, а также будет служить для проведения массовых развлекательных мероприятий и шоу (вместимость стадиона после игр будет увеличена до 45 тыс. мест).\n\nГора Фишт возвышается на 2 857 м. над уровнем моря и входит в число наиболее популярных и известных вершин на российских просторах. В переводе с адыгейского языка название горы означает «Белая голова», «Белая изморозь» или «Седоглавый». Свое название гора получила благодаря леднику на ее вершине. Сверкающая снежная шапка послужила и прообразом оригинальной архитектурной концепции центрального олимпийского стадиона. Кстати, прозрачная крыша этого спортивного сооружения позволит зрителям рассмотреть гору от подножия до пика.\n'),
(2,1,2,1,'hockey-big','12000','2012','Многофункциональный спортивный, концертный и развлекательный центр','\"Большой\"','Большой ледовый дворец \"Большой\"','Ледовый дворец «Большой» является частью комплекса объектов Международной федерации хоккея с шайбой (IIHF), который включает в себя Ледовый дворец «Большой» и Ледовую Арену «Шайба» для проведения соревнований по хоккею с шайбой и тренировочный каток. Все объекты находятся в непосредственной близости друг от друга, что обеспечит максимально комфортные условия для спортсменов и гостей Игр.\r\n\r\nКомплекс Ледового дворца «Большой» на 12 000 зрительских мест – это единое здание, перекрытое сферическим куполом. В основу концепции арены заложен образ замерзшей капли. Господствующий цвет покрытий купола – серебристый.\r\n\r\nПо окончании Игр Ледовый дворец «Большой» станет сверхсовременным многофункциональным спортивным и развлекательным объектом мирового уровня.\r\n\r\nС одной стороны, название Ледового дворца подчеркивает особенности спортивного сооружения. «Большой» станет одним из самых вместительных Олимпийских объектов, предназначенных для проведения соревнований по самым массовым видам спорта. В то же время, слово «Большой», ставшее понятным и узнаваемым среди представителей многих стран и народов, вызывает устойчивую ассоциацию с Россией – Большим театром, традициями русской школы балета, фигурного катания, хоккея и другими достижениями самой большой страны в мире.'),
(3,1,3,1,'hockey-small','7000','2012',\N,'\"Шайба\"','Ледовая арена «Шайба»','Ледовая Арена «Шайба» является частью комплекса объектов Международной федерации хоккея с шайбой (IIHF), который включает в себя Ледовый дворец «Большой» и Ледовую Арену «Шайба» для проведения соревнований по хоккею с шайбой и тренировочный каток. Все объекты находятся в непосредственной близости друг от друга, что обеспечит максимально комфортные условия для спортсменов и гостей Игр.\r\n\r\nЛедовая Арена «Шайба» рассчитана на 7 000 зрительских мест. На объекте пройдут соревнования по хоккею с шайбой в рамках Олимпийских зимних игр и по следж-хоккею в рамках Паралимпийских зимних игр.\r\n\r\nЛедовая Арена «Шайба» – объект сборно-разборного типа с возможностью демонтажа и переноса для строительства на постолимпийское использование в качестве Ледового дворца спорта в другой город Российской Федерации.\r\n\r\nШайба – спортивный снаряд, без которого невозможно представить игру в хоккей. Название с точностью отражает назначение объекта. Кроме того, для россиян клич «Шайбу!» является универсальным и узнаваемым способом поддержки хоккейной команды на международных первенствах. Таким образом, это название подчеркивает характер «русских» зимних Игр.'),
(4,1,4,1,'curling','3000','2012',\N,'\"Ледяной куб\"','Керлинговый центр «Ледяной куб»','Керлинговый Центр «Ледяной куб» расположен в прибрежном кластере в комплексе сооружений Олимпийского парка.\r\n\r\nДизайн Керлингового Центра «Ледяной куб» лаконичен. В нем прочитывается демократичность, доступность и в то же время праздничность, характерные для Олимпийских и Паралимпийских игр.\r\n\r\nКерлинговый Центр «Ледяной куб» – объект сборно-разборного типа с возможностью демонтажа и переноса для строительства на постолимпийское использование в качестве Ледовой арены для керлинга в другой город Российской Федерации.\r\n\r\nНазвание вызывает ассоциации с архитектурной формой объекта.'),
(5,1,5,1,'figure-skating','12000','июнь 2012','Ледовый дворец спорта в другом городе Российской Федерации','\"Айсберг\"','Дворец зимнего спорта «Айсберг»','В соответствии с концепцией Олимпийских игр 2014 года Дворцу Зимнего Спорта «Айсберг» отведена одна из доминирующих ролей. Это и определило место его расположения – Олимпийский парк, который станет сердцем соревнований в прибрежном кластере.\r\n\r\nДворец Зимнего Спорта «Айсберг» – объект сборно-разборного типа с возможностью демонтажа и переноса для строительства на постолимпийское использование в качестве Ледового дворца спорта в другой город Российской Федерации.\r\n\r\nНазвание вызывает ассоциации с архитектурной формой объекта. Является интернациональным, одинаково звучит на русском, английском и немецком языках.'),
(6,1,6,1,'speed-skating','8000','2012','Торгово-выставочный центр','\"Адлер-Арена\"','«Адлер-Арена»','Конькобежный центр «Адлер-Арена» представляет собой овальный стадион с двумя соревновательными дорожками и одной тренировочной. Размеры ледовой дорожки соответствует стандартам Международного союза конькобежцев (длина дорожки – 400 м). В частности, ледовая дорожка спроектирована так, чтобы обеспечить наилучшие хронометрические показатели.\r\n\r\nКрытый конькобежный центр «Адлер-Арена» размещен в центральной части Олимпийского парка.'),
(7,2,1,1,'ski','7500+7500','июнь 2013',\N,'\"Лаура\"','Комплекс для соревнований по лыжным гонкам и биатлону «Лаура»','Комплекс для соревнований по лыжным гонкам и биатлону «Лаура» расположился на гребне и склонах горного хребта Псехако в 6.5-10 км северо-восточнее поселка Красная Поляна.\r\n\r\nКомплекс состоит из двух отдельных стадионов с зонами старта и финиша, двух отдельных систем трасс для лыжных гонок и биатлона, стрельбища и зон для подготовки к соревнованиям. Вместимость Биатлонного комплекса и Лыжного комплекса по 7500 зрителей.\r\n\r\nЛаура — горная бурная река с большим количеством водопадов. Берѐт начало на южных склонах хребта Ассара в пределах Кавказского заповедника. История названия реки опирается на легенду, которая гласит, что молодая девушка по имени Лаура предпочла смерть жизни с нелюбимым человеком – старым князем. Сбежав от старика, Лаура сбросилась со скалы в реку, которой позже дали ее имя. Мурат – возлюбленный Лауры – не сумел вынести боли расставания и бросился вслед за своей невестой. Тела влюбленных так и не нашли, а местные жители говорят, что сами Боги были потрясены случившимся и приняли девушку и юношу в свою Небесную обитель на вершине священной горы Эльбрус.'),
(8,2,2,1,'mountain-ski','7500','декабрь 2011 г. – 1 пусковой комплекс, сентябрь 2012 г. – 2 пусковой комплекс','Войдет в состав крупного горнолыжного курорта','\"Роза Хутор\"','Горнолыжный центр «Роза Хутор»','Горнолыжный комплекс «Роза Хутор» расположен на хребте Аибга и представляет собой единый объект для проведения соревнований по всем горнолыжным дисциплинам: скоростной спуск, комбинации (скоростной спуск и слалом), слалом-супергигант, слалом-гигант. Общая протяженность олимпийских горнолыжных трасс составит 20 км.\r\n\r\nПроектированием всех лыжных трасс занимался всемирно известный архитектор горнолыжных трасс Международной федерации лыжного спорта (FIS) Бернар Русси. Сочи получит комплекс превосходных технических трасс международного уровня для тренировок и соревнований спортсменов со всего мира.\r\n\r\n«Роза Хутор» – уникальный горнолыжный курорт, расположенный в районе Красной Поляны. Название происходит от географического наименования плато «Роза Хутор», охватывающего примерно 1 820 га склонов хребта горы Аибга, поднимающейся от реки Мзымта. К настоящему времени горнолыжный курорт уже является крупным центром горнолыжного спорта в Северо-Кавказском регионе, также он стал местом проведения нескольких крупных международных соревнований.'),
(9,2,3,1,'ski-jumping','7500','декабрь 2011','Национальный тренировочный центр','\"Русские горки\"','Комплекс для прыжков с трамплинов «Русские Горки»','Комплекс трамплинов расположился на северном склоне хребта Аибга, в непосредственной близости к поселку Эсто-Садок. Место было специально выбрано международными экспертами на стыке двух хребтов, чтобы трамплины гармонично вписывались в окружающий ландшафт, а прыгуны были защищены от порывов бокового ветра.\r\n\r\nКомплекс состоит из самых современных олимпийских трамплинов К-95 и К-125.\r\n\r\nНазвание «Русские Горки» дает ассоциации с формой объекта (трамплины). В английском языке аттракцион, который у нас известен как «Американские горки», называется именно «Русские горки». Обыгрывается соединение аббревиатуры «Rus» и слова «Ski». Рядом находится объект «Горки Город», где расположится горная медиа-деревня.'),
(10,2,4,1,'sliding','5000','2012','Национальный тренировочный центр','\"Санки\"','Центр санного спорта «Санки»','Санно-бобслейная трасса расположилась на горнолыжном курорте «Альпика-Сервис» с финишной зоной на территории урочища «Ржаная Поляна».\r\n\r\nПередовые технологии подготовки льда обеспечивают точный и постоянный контроль над температурой трассы.\r\n\r\nМассовое катание на санках, салазках и ледянках является традиционной русской зимней забавой еще со времен Петра I. Санки всегда были неотъемлемой частью зимнего досуга любого ребенка в России. Для россиян они являются источником позитивных эмоций и приятных воспоминаний о детстве. Название позволит подчеркнуть колорит Игр и точно отразит функциональное назначение спортивного объекта. Слово «санки» благозвучно на большинстве иностранных языков.'),
(11,2,5,1,'snowboard','4000+6250','сентябрь 2012','Национальный тренировочный центр','\"Роза Хутор\"','Экстрим-парк «Роза Хутор»','Соревнования по сноуборду и фристайлу в рамках Олимпийских игр 2014 года пройдут к западу от плато «Роза Хутор».\r\n\r\nВместимость Фристайл-центра: 4000 зрителей. \r\nВместимость Сноуборд-парка: 6250 зрителей.\r\n\r\nУникальные снежные условия в сочетании со специализированными трассами для лыжного кросса, акробатики, могула, сноуборд-кросса, параллельного слалома-гиганта, хаф-пайпа гарантированно сделают этот объект постоянным местом проведения соревнований самого высокого мирового уровня.')	;
#	TC`tbl_placegroup`utf8_general_ci	;
CREATE TABLE `tbl_placegroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` int(11) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `prior` (`prior`),
  KEY `visible` (`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_placegroup`utf8_general_ci	;
INSERT INTO `tbl_placegroup` VALUES 
(1,1,1,'sea','Прибрежный кластер','Центральным объектом прибрежного кластера станет Олимпийский парк. Он объединит все спортивные объекты, парковую зону и объекты инфраструктуры. Впервые в истории зимних Олимпийских и Паралимпийских игр все ледовые арены будут находиться в шаговой доступности друг от друга. Одновременно в парке могут находиться около 70 тыс. посетителей.'),
(2,2,1,'mountain','Горный кластер','В состав Горного кластера войдут Комплекс для соревнований по лыжным гонкам и биатлону «Лаура», Центр санного спорта «Санки», Горнолыжный центр «Роза Хутор», Комплекс для прыжков с трамплинов «Русские горки», а также Экстрим-парк «Роза Хутор».')	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `filter_menu` int(10) NOT NULL DEFAULT '0',
  `task_pagesize` int(10) NOT NULL DEFAULT '20',
  `organization_pagesize` int(10) NOT NULL DEFAULT '20',
  `taskstage_pagesize` int(10) NOT NULL DEFAULT '20',
  `taskprior_pagesize` int(10) NOT NULL DEFAULT '20',
  `organizationtype_pagesize` int(10) NOT NULL DEFAULT '20',
  `organizationgroup_pagesize` int(10) NOT NULL DEFAULT '20',
  `organizationregion_pagesize` int(10) NOT NULL DEFAULT '20',
  `menu_pagesize` int(10) NOT NULL DEFAULT '20',
  `item_pagesize` int(10) NOT NULL DEFAULT '20',
  `menuitem_pagesize` int(10) NOT NULL DEFAULT '20',
  `organization_sort` varchar(255) NOT NULL DEFAULT 'value',
  `tasktype_pagesize` int(10) NOT NULL DEFAULT '20',
  `filter_task_status` int(10) NOT NULL DEFAULT '0',
  `filter_deal_status` int(10) NOT NULL DEFAULT '0',
  `contact_type_pagesize` int(10) NOT NULL DEFAULT '20',
  `filter_deal_source_id` int(10) NOT NULL DEFAULT '0',
  `filter_deal_stage_id` int(10) NOT NULL DEFAULT '0',
  `filter_contact_type_id` int(10) NOT NULL DEFAULT '0',
  `filter_item_action` varchar(255) NOT NULL DEFAULT '',
  `filter_item_controller` varchar(255) NOT NULL DEFAULT '',
  `filter_item_module` varchar(255) NOT NULL DEFAULT '',
  `filter_item_parent_id` int(10) NOT NULL DEFAULT '0',
  `filter_organization_group_id` int(10) NOT NULL DEFAULT '0',
  `filter_organization_region_id` int(10) NOT NULL DEFAULT '0',
  `filter_organization_type_id` int(10) NOT NULL DEFAULT '0',
  `filter_task_owner_id` int(10) NOT NULL DEFAULT '0',
  `filter_task_user_id` int(10) NOT NULL DEFAULT '0',
  `filter_task_type_id` int(10) NOT NULL DEFAULT '0',
  `filter_task_stage_id` int(10) NOT NULL DEFAULT '0',
  `filter_task_prior_id` int(10) NOT NULL DEFAULT '0',
  `filter_deal_probability` int(10) NOT NULL DEFAULT '0',
  `filter_menu_parent_id` int(10) NOT NULL DEFAULT '0',
  `filter_payment_type_id` int(10) NOT NULL DEFAULT '0',
  `mobile_phone` varchar(10) NOT NULL DEFAULT '9281234567',
  `current_page_url` varchar(255) NOT NULL DEFAULT '',
  `current_page_rights` varchar(255) NOT NULL DEFAULT '',
  `current_page_datetime` int(11) NOT NULL DEFAULT '0',
  `filter_edizm_id` int(10) NOT NULL DEFAULT '0',
  `filter_safetyclass_id` int(10) NOT NULL DEFAULT '0',
  `filter_deal_type_id` int(10) NOT NULL DEFAULT '0',
  `placegroup_pagesize` int(10) NOT NULL DEFAULT '20',
  `place_pagesize` int(10) NOT NULL DEFAULT '20',
  `country_pagesize` int(10) NOT NULL DEFAULT '20',
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Евгений','Дмитриченко',1,20,20,20,10,20,20,10,20,20,20,'value',10,2,0,20,0,0,0,'0','0','0',1,0,0,0,0,0,0,0,0,0,0,0,'9185569410','/bugtracker/default/index/Task_sort/task_prior_id?ajax=data-grid','Чтение, Редактирование, Удаление',1383262502,0,0,0,20,20,20),
(5,'demo','demo',0,20,20,20,20,20,20,20,20,20,20,'value',20,0,0,20,0,0,0,'','','',0,0,0,0,0,0,0,0,0,0,0,0,'9281234567','','',0,0,0,0,20,20,20)	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles_fields`utf8_general_ci	;
INSERT INTO `tbl_profiles_fields` VALUES 
(1,'first_name','Имя','VARCHAR',255,3,1,'','','Неверное имя (длина должна быть от 3 до 50 символов).','','','','',1,3),
(2,'last_name','Фамилия','VARCHAR',255,3,1,'','','Неверная фамилия (длина должна быть от 3 до 50 символов).','','','','',2,3),
(12,'filter_menu','Filter menu','INTEGER',10,0,0,'','','','','0','','',0,0),
(30,'task_pagesize','Task pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(31,'organization_pagesize','Organization pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(36,'taskstage_pagesize','Taskstage pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(37,'taskprior_pagesize','Taskprior pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(40,'organizationtype_pagesize','Organizationtype pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(41,'organizationgroup_pagesize','Organizationgroup pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(42,'organizationregion_pagesize','Organizationregion pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(43,'menu_pagesize','Meu pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(44,'item_pagesize','Item pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(45,'menuitem_pagesize','Menuitem pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(52,'organization_sort','Organization sort','VARCHAR',255,0,0,'','','','','value','','',0,0),
(53,'tasktype_pagesize','Tasktype pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(86,'filter_task_status','Filter task status','INTEGER',10,0,0,'','','','','0','','',0,0),
(87,'filter_deal_status','Filte rdeal status','INTEGER',10,0,0,'','','','','0','','',0,0),
(89,'contact_type_pagesize','Contact type pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(96,'filter_deal_source_id','Filter deal source id','INTEGER',10,0,0,'','','','','0','','',0,0),
(97,'filter_deal_stage_id','Filter deal stage id','INTEGER',10,0,0,'','','','','0','','',0,0),
(98,'filter_contact_type_id','Filter contact type id','INTEGER',10,0,0,'','','','','0','','',0,0),
(99,'filter_item_action','Filter item action','VARCHAR',255,0,0,'','','','','','','',0,0),
(100,'filter_item_controller','Filter item controller','VARCHAR',255,0,0,'','','','','','','',0,0),
(101,'filter_item_module','Filter item module','VARCHAR',255,0,0,'','','','','','','',0,0),
(102,'filter_item_parent_id','Filter item parent id','INTEGER',10,0,0,'','','','','0','','',0,0),
(103,'filter_organization_group_id','Filter organization group id','INTEGER',10,0,0,'','','','','0','','',0,0),
(104,'filter_organization_region_id','Filter organization region id','INTEGER',10,0,0,'','','','','0','','',0,0),
(105,'filter_organization_type_id','Filter organization type id','INTEGER',10,0,0,'','','','','0','','',0,0),
(106,'filter_task_owner_id','Filter task owner id','INTEGER',10,0,0,'','','','','0','','',0,0),
(107,'filter_task_user_id','Filter task user id','INTEGER',10,0,0,'','','','','0','','',0,0),
(108,'filter_task_type_id','Filter task type id','INTEGER',10,0,0,'','','','','0','','',0,0),
(109,'filter_task_stage_id','Filter task stage id','INTEGER',10,0,0,'','','','','0','','',0,0),
(110,'filter_task_prior_id','Filter task prior id','INTEGER',10,0,0,'','','','','0','','',0,0),
(111,'filter_deal_probability','Filte rdeal probability','INTEGER',10,0,0,'','','','','0','','',0,0),
(112,'filter_menu_parent_id','Filter menu parent id','INTEGER',10,0,0,'','','','','0','','',0,0),
(118,'filter_payment_type_id','Filter payment type id','INTEGER',10,0,0,'','','','','0','','',0,0),
(121,'mobile_phone','Мобильный телефон','VARCHAR',10,0,1,'','','','','9281234567','','',3,2),
(133,'current_page_url','Current page URL','VARCHAR',255,0,0,'','','','','','','',0,0),
(134,'current_page_rights','Current page rights','VARCHAR',255,0,0,'','','','','','','',0,0),
(135,'current_page_datetime','Current page datetime','INTEGER',11,0,0,'','','','','0','','',0,0),
(138,'filter_edizm_id','Filter edizm id','INTEGER',10,0,0,'','','','','0','','',0,0),
(139,'filter_safetyclass_id','Filter safetyclass id','INTEGER',10,0,0,'','','','','0','','',0,0),
(142,'filter_deal_type_id','Filter deal type id','INTEGER',10,0,0,'','','','','0','','',0,0),
(146,'placegroup_pagesize','Placegroup pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(147,'place_pagesize','Place pagesize','INTEGER',10,1,0,'','','','','20','','',0,0),
(148,'country_pagesize','Country pagesize','INTEGER',10,1,0,'','','','','20','','',0,0)	;
#	TC`tbl_sport`utf8_general_ci	;
CREATE TABLE `tbl_sport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sportgroup_id` int(11) DEFAULT NULL,
  `prior` int(11) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `game_id` (`sportgroup_id`),
  KEY `prior` (`prior`),
  KEY `visible` (`visible`),
  CONSTRAINT `tbl_sport_ibfk_1` FOREIGN KEY (`sportgroup_id`) REFERENCES `tbl_sportgroup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8	;
#	TD`tbl_sport`utf8_general_ci	;
INSERT INTO `tbl_sport` VALUES 
(1,1,1,1,'alpine','Горные лыжи','В 1936 году соревнования по горным лыжам были впервые включены в программу IV Олимпийских зимних игр в Гармиш-Партенкирхене.'),
(2,1,2,1,'biathlon','Биатлон','Изначально биатлон был, скорее, способом охоты жителей Северной Европы, нежели спортом.'),
(3,1,3,1,'bobsl','Бобслей','В программу Олимпийских зимних игр бобслей был включен в 1924 году в Шамони.'),
(4,1,4,1,'cross-country','Лыжные гонки','На I Олимпийских зимних играх в Шамони (Франция) в 1924 г. в олимпийскую программу вошли лыжные гонки для мужчин на дистанциях 18 и 50 км.'),
(5,1,5,1,'curling','Керлинг','Кёрлинг зародился в XVI веке в Шотландии. В него играли зимой на замёрзших прудах, болотах и озёрах.'),
(6,1,6,1,'figure-skating','Фигурное катание на коньках','Фигурное катание на коньках является старейшей дисциплиной в программе Олимпийских игр.'),
(7,1,7,1,'freestyle','Фристайл','Впервые показательные выступления по фристайлу были включены в программу Олимпийских зимних игр в 1988 году в Калгари.'),
(8,1,8,1,'nordic','Лыжное двоеборье','Впервые индивидуальные соревнования по лыжному двоеборью были включены в олимпийскую программу в 1924 году в Шамони.'),
(9,1,9,1,'ice-hockey','Хоккей на льду','До сих пор существует несколько мнений относительно родины хоккея на льду.'),
(10,1,10,1,'sliding','Санный спорт','Историки полагают, что сани существовали уже в 800 году нашей эры в районе Слаген, вблизи фьорда Осло.'),
(11,1,11,1,'short-speed-skating','Шорт-трек','На Олимпийских зимних играх 1988 года в Калгари шорт-трек был показательной дисциплиной.'),
(12,1,12,1,'skeleton','Скелетон','Прародителем скелетона считается спуск с гор на тобоггане – бесполозных деревянных санях, распространенных среди канадских индейцев.'),
(13,1,13,1,'jumping','Прыжки на лыжах с трамплина','Прыжки на лыжах с трамплина входят в программу Олимпийских игр с 1924 года, когда в Шамони состоялись первые в мировой истории Олимпийские зимние игры.'),
(14,1,14,1,'snowboard','Сноуборд','На Олимпийских играх в Нагано в 1998 году сноуборд дебютировал в качестве олимпийской дисциплины.'),
(15,1,15,1,'speed-skating','Скоростной бег на коньках','Скоростной бег на коньках среди мужчин был включен в программу Олимпийских зимних игр в 1924 году.'),
(16,2,1,1,'alpine','Горнолыжный спорт','Горнолыжный спорт практикуется во всем мире и включает в себя семь видов соревнований.'),
(17,2,2,1,'biathlon','Биатлон','Впервые биатлон появился в программе соревнований спортсменов c физическими нарушениями во время Игр в Инсбруке в 1988 году.'),
(18,2,3,1,'cross-country','Лыжные гонки','Лыжные гонки впервые были проведены на Паралимпийских зимних играх, которые прошли в 1976 году в Орнсколддсвике (Швеция).'),
(19,2,4,1,'ice-hockey','Следж хокей на льду','После своего дебюта на Олимпийских зимних играх в Лиллехаммере в 1994 году Паралимпийский вариант хоккея на льду быстро стал одним из самых привлекательных для болельщиков зрелищ.'),
(20,2,5,1,'curling','Керлинг на колясках','Керлинг на колясках впервые вошел в Паралимпийскую программу в 2006 году во время Игр в Турине.'),
(21,1,\N,0,'','Церемония открытия','Церемония открытия зимних Олимпийских игр 2014 в Сочи'),
(22,2,\N,0,'','Церемония открытия','Церемония открытия зимних Паралимпийских игр 2014 в Сочи'),
(23,1,\N,0,'','Церемония закрытия','Церемония закрытия зимних Олимпийских игр 2014 в Сочи'),
(24,2,\N,0,'','Церемония закрытия','Церемония закрытия зимних Паралимпийских игр 2014 в Сочи')	;
#	TC`tbl_sportgroup`utf8_general_ci	;
CREATE TABLE `tbl_sportgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` int(11) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `prior` (`prior`),
  KEY `visible` (`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_sportgroup`utf8_general_ci	;
INSERT INTO `tbl_sportgroup` VALUES 
(1,1,1,'olimpic-games','Олимпийские игры','Олимпийские зимние игры в Сочи 2014','Олимпийские игры – самое яркое спортивное событие в мире. Сотни атлетов готовятся к этому старту всю жизнь. Те, кому удается взойти на олимпийский пьедестал, становятся примером для миллионов. Их достижения навсегда остаются в истории спорта и Олимпийского движения.\r\n\r\nСовременные Олимпийские игры имеют тысячелетнюю историю и сейчас находятся на пике своего развития.\r\n\r\nВ октябре 2009 года в Копенгагене прошел XIII Олимпийский конгресс – беспрецедентный по своему масштабу. По итогам конгресса были приняты решения, которые определили вектор развития Олимпийского движения на ближайшие 15 лет.\r\n\r\nОдним из них является решение расширить программу Олимпийских летних игр: с 2016 года поклонники регби и гольфа смогут болеть за своих любимых спортсменов на олимпийских соревнованиях.\r\n\r\nСоревнования Олимпийских Игр в Сочи пройдут по 7 зимним видам спорта:\r\n\r\n    Биатлон\r\n    Бобслей: бобслей и скелетон\r\n    Керлинг\r\n    Хоккей на льду\r\n    Санный спорт\r\n    Конькобежный спорт: фигурное катание, шорт-трек и скоростной бег на коньках\r\n    Лыжный спорт: горные лыжи, лыжные гонки, лыжное двоеборье, прыжки на лыжах с трамплина, фристайл и сноуборд'),
(2,2,1,'paralimpic-games','Паралимпийские игры','Паралимпийские зимние игры в Сочи 2014','Вторая мировая война заставила по-новому взглянуть на вопросы реабилитации инвалидов. В 1944 году невропатолог и нейрохирург профессор Людвиг Гуттман основал медицинский центр для лечения повреждений спинного мозга в госпитале Сток-Мандевилль (Великобритания). Позднее он стал основоположником международных Сток-Мандевильских игр, в которых участвовали люди с повреждениями опорно-двигательного аппарата. Эти игры стали прототипом Паралимпийских.\r\n\r\nПервые Паралимпийские летние игры состоялись в 1960 году в Риме.\r\n\r\nПервые Паралимпийские зимние игры прошли в 1976 году в шведском Орнсколддсвике.\r\n\r\nСоревнования Паралимпийских зимних игр в Сочи пройдут по пяти зимним видам спорта:\r\n\r\n    Горные лыжи\r\n    Биатлон\r\n    Лыжные гонки\r\n    Следж-хоккей на льду\r\n    Керлинг на колясках\r\n')	;
#	TC`tbl_sporttext`utf8_general_ci	;
CREATE TABLE `tbl_sporttext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sport_id` int(11) NOT NULL,
  `prior` int(11) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `header` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sport_id` (`sport_id`),
  KEY `visible` (`visible`),
  CONSTRAINT `tbl_sporttext_ibfk_1` FOREIGN KEY (`sport_id`) REFERENCES `tbl_sport` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8	;
#	TD`tbl_sporttext`utf8_general_ci	;
INSERT INTO `tbl_sporttext` VALUES 
(1,1,1,1,'Немного истории','В 1936 году соревнования по горным лыжам были впервые включены в программу IV Олимпийских зимних игр в Гармиш-Партенкирхене. Тогда в программу вошли только слалом и скоростной спуск. На Олимпийских играх 1952 года в Осло награды разыгрывались уже в трех видах соревнований — слаломе, гигантском слаломе и скоростном спуске. С XV Олимпийских зимних игр в Калгари в 1988 году в программу соревнований горнолыжников добавился еще и супергигантский слалом.'),
(2,1,2,1,'Горные лыжи в России','В начале 1900-х годов в России среди лыжников стали выделяться так называемые «горняки», которые отдавали предпочтение катанию с гор на скорость, а затем увлеклись и фигурным катанием на лыжах, то есть спусками с поворотами, что впоследствии было названо слаломом. В последующие годы горнолыжный спорт активно развивался, и уже в 70-е годы в секциях и детских спортивных школах занималось около 28 тысяч спортсменов.'),
(3,1,3,1,'Горные лыжи как они есть','В программу Олимпийских игр по горным лыжам включены 10 видов соревнований: пять среди мужчин и пять среди женщин. В них входит скоростной спуск, слалом, гигантский слалом, супер-гигант и супер-комбинация. Для различных видов соревнований готовятся различные трассы. Всего разыгрывается 10 комплектов наград.'),
(4,1,4,1,'Скоростной спуск','В скоростном спуске используются самые длинные трассы из всех видов соревнований по горным лыжам, а спортсмены развивают самые высокие скорости (до 120 км/ч). Спортсмены проходят дистанцию по одному. Самый быстрый лыжник выигрывает соревнования.'),
(5,1,5,1,'Слалом','В слаломе спортсменам необходимо пройти трассу, размеченную флажками и воротами, которые расположены друг к другу ближе, чем в скоростном спуске, слаломе-гиганте и супергигантском слаломе. На соревнованиях спортсменам необходимо преодолеть две трассы, из суммы результатов и складывается итоговое время.'),
(6,1,6,1,'Гигантский слалом','В гигантском слаломе ворота на трассе расположены друг от друга дальше, чем в слаломе, но не так далеко, как в супер-гиганте. Количество ворот для мужчин — 56-70, для женщин — 46-58. Результат складывается из времени прохождения двух различных трасс.'),
(7,1,7,1,'Супер-гигант','Супер-гигант представляет собой вид соревнования, объединяющий скоростной спуск и слалом-гигант. Спортсмены в супер-гиганте развивают такую же высокую скорость, как и при скоростном спуске, а траектория трассы при этом аналогична траектории трассы в слаломе. Спортсмены проходят трассу, ворота на которой находятся примерно на том же расстоянии, что и в слаломе-гиганте. На прохождение трассы дается только одна попытка.'),
(8,1,8,1,'Супер-комбинация','Супер-комбинация представляет собой вид программы, объединяющий в себе скоростной спуск и слалом. Скоростной спуск иногда меняют на супер-гигант.'),
(9,1,9,1,'Спортивное оборудование','<ul>\r\n<li>Специальные пластиковые ботинки. Крепления фиксируют ноги горнолыжника на лыжах. Перчатки для горных лыж сделаны из кожи или синтетических материалов.</li>\r\n<li>Очки предохраняют глаза от ветра, снега, повышенного ультрафиолета на высоте и светоотражения от снега.</li>\r\n<li>Шлем защищает спортсмена от травм и должен плотно прилегать в голове.</li>\r\n<li>Лыжные палки для скоростного спуска и супер-гиганта изогнуты, что позволяет уменьшить сопротивление воздуха при спуске.</li>\r\n<li>Лыжи изготавливаются из различных материалов (дерево, композитные материалы) и подбираются индивидуально для каждого спортсмена. Лыжи для скоростного спуска на 30% длиннее, чем те, что используются в слаломе. Это позволяет обеспечить дополнительную устойчивость при высоких скоростях.</li>\r\n<li>Форму для спортсменов шьют из тканей, минимизирующих сопротивление воздуха.</li>\r\n</ul>'),
(10,2,1,1,'Немного истории','Изначально биатлон был, скорее, способом охоты жителей Северной Европы, нежели спортом. Сейчас биатлон представляет собой комбинацию лыжных гонок и пулевой стрельбы из малокалиберной винтовки. Биатлон входит в программу Олимпийских игр с 1960 года.'),
(11,2,2,1,'Биатлон в России','В России развитие биатлона в его современном виде началось только в начале XX века. В 1920-30 годах лыжные соревнования, совмещенные со стрельбой из винтовки, были широко распространены в Красной армии. Спортсмены проходили дистанцию 50 км в военной форме и поражали несколько огневых рубежей. Стимулом для развития биатлона в СССР стали спартакиады народов России, которые, подобно Олимпийским играм, проводились раз в четыре года.\r\n\r\nПервым советским олимпийским чемпионом в биатлоне в гонке на 20 км стал Владимир Меланин в 1964 году в Инсбруке. До этого на этой дистанции Владимир Меланин трижды становился чемпионом мира.\r\n\r\nВ 1992 году женский биатлон включили в программу XVI Олимпийских зимних игр в Альбервиле, Франция. На этих играх первой олимпийской чемпионкой стала Анфиса Резцова на дистанции 7,5 км.\r\n\r\nСборная России, СНГ и СССР побеждала в биатлоне на Олимпийских играх 18 раз, из них 8 раз в эстафете.'),
(12,2,3,1,'Биатлон как он есть','На сегодняшний день в программу Олимпийских зимних игр входят пять видов соревнований по биатлону для мужчин и пять для женщин: индивидуальная гонка, спринт, гонка преследования, гонка с массовым стартом и эстафета; а также смешанная эстафета.'),
(13,2,4,1,'Индивидуальная гонка','Индивидуальная гонка — классический вид биатлонной гонки на 20 км для мужчин и на 15 км для женщин с четырьмя огневыми рубежами. Биатлонисты стартуют с интервалом 30 секунд или 1 минута. Первая и третья стрельба — «лёжа», вторая и четвёртая — «стоя». Каждый биатлонист сам выбирает себе стрелковый коридор на стрельбище. За каждый промах к времени гонки биатлониста прибавляется штрафная минута.'),
(14,2,5,1,'Спринт','Спринт — это укороченная версия индивидуальной гонки, где скорость играет ключевую роль. За каждый промах спортсмен получает штрафной круг в 150 м. Длина дистанции в спринте у мужчин &mdash 10 км, у женщин &mdash 7,5 км. Стрельба ведётся на двух огневых рубежах поочередно из положений «лёжа» и «стоя».'),
(15,2,6,1,'Гонка преследования','Гонка преследования. Участники гонки преследования стартуют в таком порядке и с такими временными интервалами, с какими они пришли на финиш в спринте. Длина дистанции в гонке преследования у мужчин — 12,5 км, у женщин — 10 км. Стрельба ведётся на четырёх огневых рубежах: первые два из положения «лёжа», два последних — «стоя». За каждый промах спортсмен получает штрафной круг в 150 м.'),
(16,2,7,1,'Гонка с массовым стартом','Гонка с массовым стартом — один из самых молодых видов биатлонных гонок. Длина дистанции 15 км для мужчин и 12,5 км для женщин со стрельбой на четырёх огневых рубежах. 30 лучших спортсменов (биатлонистов или биатлонисток) стартуют одновременно с общего старта. Первая и вторая стрельба выполняются «лёжа», третья и четвёртая — «стоя». Спортсмены занимают места на огневых рубежах в соответствии с порядком прихода на стрельбище (при первой стрельбе — в соответствии со стартовым номером). За каждый промах предусмотрено прохождение штрафного круга длиной 150 м.'),
(17,2,8,1,'Эстафета','В эстафете участвуют национальные сборные команды, состоящие из 4 человек. Гонка начинается с одновременного старта 1-го этапа. Длина дистанции на каждом этапе у мужчин — 7,5 км, у женщин — 6 км. Стрельба ведётся на двух огневых рубежах из положения «лёжа» и «стоя». В отличие от индивидуальных гонок, биатлонист может потратить на каждую мишень по 8 патронов: 5 находятся в магазине, остальные 3, при необходимости, заряжаются вручную. Если после использования запасных патронов остались незакрытые мишени, спортсмен должен преодолеть штрафные круги в 150 м, количество которых соответствует количеству неразбитых мишеней.'),
(18,2,9,1,'Смешанная эстафета','Каждая национальная команда состоит из 4 спортсменов (2 женщины и 2 мужчин). Женщины бегут 6 км, мужчины — 7,5км в следующем порядке: Женщина — Женщина — Мужчина — Мужчина. Каждый спортсмен стреляет дважды (лежа — стоя), с тремя запасными патронами на каждом огневом рубеже. Если после использования запасных патронов остались незакрытые мишени, спортсмен должен преодолеть штрафные круги в 150 м, количество которых соответствует количеству неразбитых мишеней.'),
(19,2,10,1,'Спортивное оборудование','В биатлоне разрешены любые лыжные техники, однако запрещено использовать какие-либо средства, кроме лыж и лыжных палок.\r\n<ul>\r\n<li>Лыжные ботинки, позволяющие устойчиво стоять на лыжах и контролировать движение.</li>\r\n<li>Лыжные палки, изготовленные из современных материалов, например, из карбона. Их длина не может превышать рост спортсмена.</li>\r\n<li>Спортивная винтовка для биатлона, калибром 5,6 мм. Переносится спортсменами за спиной на специальных заплечных ремнях стволом вверх.</li>\r\n<li>Специальный костюм — гоночный комбинезон, который помогает поддерживать стабильную температуру тела и уменьшает сопротивление ветра.</li>\r\n<li>Лыжи, минимальная длина которых должна быть на 4 см меньше, чем рост спортсмена. Для лучшего скольжения их смазывают специальными парафинами и смазками.</li>\r\n</ul>'),
(20,3,1,1,'Немного истории','В программу Олимпийских зимних игр бобслей был включен в 1924 году в Шамони. Тогда соревнования проводили на четырехместных бобах (санях), в 1928 году — на четырёхместных или на пятиместных, причем участие в них принимали только мужчины. Начиная с 1932 года (за исключением Игр в Скво-Вэлли в 1960 году, где не было бобслейной трассы), соревнования проводятся на двух — и четырехместных бобах. В октябре 1999 года женский бобслей был добавлен в программу Олимпийских зимних игр, и уже в 2002 году в Солт-Лейк-Сити женщины впервые приняли участие в соревнованиях на двухместных бобах.'),
(21,3,2,1,'Бобслей в России','В России началом развития бобслея считается 1980 год, когда Комитетом по физической культуре и спорту при Совете Министров СССР было принято Постановление о создании сборной команды СССР по бобслею. Одновременно с созданием сборной команды страны началось развитие бобслея в спортивных обществах.'),
(22,3,3,1,'Бобслей как он есть','Бобслей представляет собой скоростной спуск с гор по специальным трассам с искусственным намораживанием льда на управляемых санях (бобах).\r\n\r\nОлимпийские соревнования по бобслею в каждом виде программы проходят в два дня — по 2 заезда в день. Победительницей становится команда, чье суммарное время (по всем 4 заездам) минимально. Если две команды финишировали с одинаковым временем, то они получают одинаковые награды. Различают соревнования мужчин и женщин.\r\n\r\nВ программу Олимпийских игр входят три вида соревнований: мужчины на двух- и четырехместных бобах, женщины на двухместных бобах. Таким образом, всего разыгрывается 3 комплекта наград.'),
(23,3,4,1,'Спортивное оборудование','<ul>\r\n<li>Боб — управляемые сани. Он состоит из главного корпуса, рамы, передней и задней оси, стальных сидений. Существуют двухместные и четырехместные бобы. Пилот управляет бобом руками и пальцами, управление осуществляется с помощью колец, которые привязаны канатами к рулевому механизму.</li>\r\n<li>Специальные высокотехнологичные пластиковые шлемы, которые спортсмены надевают для предотвращения травм головы.</li>\r\n<li>Особые ботинки для бобслея сделаны из синтетического материала и имеют шипы на подошвах для увеличения тяги во время стартового разгона.</li>\r\n</ul>'),
(24,10,1,1,'Немного истории','\"Luge\" - это французское слово для обозначения саней. Историки полагают, что сани существовали уже в 800 году нашей эры в районе Слаген, вблизи фьорда Осло. Уже тогда викинги использовали сани с двумя полозьями, похожие на те, что существуют в наши дни.\r\n\r\nКак вид спорта, санный спорт появился в Швейцарии. В 1879 году в Давосе была построена первая трасса для соревнований по санному спорту длиной 4 км, соединившая Давос с деревней Клостерс. Спустя четыре года в Давосе прошел первый международный турнир по санному спорту.\r\n\r\nСанный спорт вошел в программу Олимпийских игр в Инсбруке в 1964 г.'),
(25,10,2,1,'Санный спорт в России','В России первые официальные соревнования по санному спорту были проведены в 1910 году в Москве на Воробьевых горах.\r\n\r\nВ 1969 году в России была создана Федерация санного спорта, а в 1971 году проведен первый Чемпионат СССР в Братске.\r\n\r\nВ 1972 году спортсмены нашей страны впервые приняли участие в Олимпийских играх в японском Саппоро.'),
(26,10,3,1,'Санный спорт как он есть','Санный спорт — один из самых экстремальных олимпийских зимних видов спорта. Он представляет собой соревнования в скоростном спуске на одноместных или двухместных санях по специальной трассе с искусственным намораживанием льда.\r\n\r\nСпортсмен стартует из положения «сидя», после отталкивания участник принимает положение «лежа на спине». Управление санями происходит за счет смещения центра тяжести тела спортсмена. Побеждает спортсмен, прошедший трассу за наименьшее время. Во время заезда скорость саней может достигать 140 км/ч.\r\n\r\nВ программу Олимпийских зимних игр по санному спорту входят индивидуальные соревнования среди мужчин на одноместных санях, женщин на одноместных санях и мужчин на двухместных санях. Также в спортивную программу Олимпийских зимних игр в Сочи впервые добавлена эстафета. Состязания проходят на одной трассе, но для женщин и мужчин на двухместных санях дистанция короче.'),
(27,10,4,1,'Индивидуальные соревнования','Индивидуальные соревнования у мужчин и женщин на одноместных санях проходят в течение двух дней по два заезда в день. Наименьшее суммарное время четырёх заездов определяет победителя.'),
(28,10,5,1,'Соревнования мужчин на двухместных санях','В соревнованиях мужчин на двухместных санях оба заезда проводятся в один день, наименьшее суммарное время двух заездов определяет победителя. В правилах не сказано, что двухместный экипаж должен состоять из людей одного пола, но по традиции в соревнованиях участвуют мужчины.\r\n\r\nНа Играх 2014 года в Сочи команды впервые примут участие в эстафете. Состав команды от каждой страны: женщина (одноместные сани), мужчина (одноместные сани) и мужчины на двухместных санях. Последовательность заездов каждой команды: женщина — мужчина — двойка.\r\n\r\nНа финише каждый спортсмен должен дотронуться до специального тачпэда (touch-pad), что автоматически открывает ворота на старте для следующего представителя команды. Когда третий участник команды достигает зоны передачи эстафеты и дотрагивается до тачпэда, определяется общее время команды (от старта первого представителя команды до финиша последнего).'),
(29,10,6,1,'Спортивное оборудование','<ul>\r\n<li>Специальные костюмы, которые позволяют уменьшить сопротивление ветра.</li>\r\n<li>Специальные перчатки для санного спорта с шипами на пальцах помогают спортсменам разгоняться на старте.</li>\r\n<li>Шлем с прозрачной или тонированной маской, которая опускается до подбородка, чтобы уменьшить сопротивление ветра.</li>\r\n<li>Специальная обувь, имеющая, по правилам, жесткую гладкую подошву. Обувь саночников на спортивном сленге называется «калипсо».</li>\r\n</ul>'),
(30,4,1,1,'Немного истории','На I Олимпийских зимних играх в Шамони (Франция) в 1924 г. в олимпийскую программу вошли лыжные гонки для мужчин на дистанциях 18 и 50 км. Соревнования женщин по лыжным гонкам на дистанции 10 км впервые вошли в программу на Олимпийских играх 1952 года в Осло (Норвегия). Первой олимпийской чемпионкой стала советская спортсменка Любовь Баранова (Козырева). В последующие годы программа олимпийских соревнований менялась, появлялись новые дистанции и форматы, но самое значительное событие произошло в 1988 году в Канаде, когда на Олимпийских играх в Калгари впервые прошли соревнования свободным стилем. Следующим инновационным годом стал год Олимпиады в Солт-Лейк-Сити (США) — 2002, когда впервые состоялась гонка с общим стартом. На этих же играх впервые прошли соревнования в новом виде программы – в спринте.'),
(31,4,2,1,'Лыжные гонки в России','Днем рождения лыжных гонок в России принято считать 29 декабря 1895 г. В этот день в Москве состоялось торжественное открытие первой организации, руководящей развитием лыжного спорта - Московского клуба лыжников. 7 февраля 1910 года на дистанции 30 верст был разыгран титул первого всероссийского чемпиона по лыжным гонкам, который завоевал Павел Бычков. За всю историю российского лыжного спорта 42 спортсмена становились олимпийскими чемпионами. Самыми титулованными являются следующие спортсмены: Любовь Егорова — 6-кратная олимпийская чемпионка; Лариса Лазутина — 5 золотых олимпийских медалей; Николай Зимятов, Галина Кулакова, Раиса Сметанина — по 4 золотые медали; Елена Вяльбе — 3-кратная олимпийская чемпионка.'),
(32,4,3,1,'Лыжные гонки как они есть','В программу Олимпийских зимних игр включено 12 видов соревнований по лыжным гонкам: шесть среди мужчин и шесть среди женщин, среди которых индивидуальные гонки и гонки с общим стартом, скиатлон, эстафета, индивидуальный и командный спринт.'),
(33,4,4,1,'Индивидуальная гонка','Индивидуальная гонка — лыжники стартуют с интервалом в 30 секунд, победитель определяется по наименьшему времени, затраченному на прохождение дистанции. Участники стартуют в обратном порядке от их сезонного рейтинга, то есть спортсмен с наивысшим рейтингом стартует последним. Лыжник, которого обгоняет преследователь, должен уступить лыжню по первому требованию более быстрого участника. На Олимпийских зимних играх в Сочи мужчины бегут классическим стилем 15 км, а женщины — 10 км.'),
(34,4,5,1,'Гонка с общим стартом','В гонке с общим стартом все спортсмены стартуют одновременно. 60-80 спортсменов выстраиваются рядами по 7-11 человек и стартуют по сигналу стартового пистолета. Этот формат сравним с велосипедными гонками, когда участники используют различные стратегии и тактики в ходе гонки, а на финише демонстрируют свои спринтерские способности. Мужчины и женщины бегут свободным стилем: первые проходят дистанцию 50км, вторые – 30км. Использование коротких кругов позволяет зрителям на стадионе видеть участников каждые 10-12 минут. Победителем становится первый финишировавший. Нередко на финиш приходят одновременно до 10 гонщиков и бьются за победу, часто их результаты определяются при помощи фото-финиша.'),
(35,4,6,1,'Скиатлон','Скиатлон — один из самых интересных видов соревнований по лыжным гонкам. Первую половину дистанции гонщики проходят классическим стилем на классических лыжах, а потом на стадионе меняют их на коньковые и завершают соревнование свободным стилем. Во время смены лыж секундомер не останавливается, как и на «пит-стопах» Формулы-1. Первый пришедший на финиш и становится победителем в скиатлоне. Мужчины бегут два раза по 15 км (по кругу 3,75км) каждым стилем (общая дистанция 30км), женщины два раза преодолевают по 7,5 км (по кругу 2,5 км) при общей длине дистанции 15 км. Соревновательная трасса пролегает, как правило, таким образом, что лыжники проходят через стадион несколько раз.'),
(36,4,7,1,'Индивидуальный спринт','Соревнования по индивидуальному спринту начинаются с квалификационного раунда, когда лыжники стартуют с интервалом 15 секунд и бегут круг 1,2-1,3 км (женщины) или 1,4-1,6 км (мужчины). Первые 30 лучших участников проходят в следующий круг и распределяются по четвертьфинальным забегам. В четвертьфинале, полуфинале и финале стартуют 6 человек. В следующий раунд проходят первые два спортсмена из каждого забега и два лыжника «lucky losers», показавшие лучшее время среди занявших 3-4 места. В финале участвуют 6 гонщиков, которые ведут борьбу за золотую медаль.'),
(37,4,8,1,'Командный спринт','Командный спринт проводится как эстафета команд, состоящих из двух спортсменов, которые по очереди преодолевают дистанцию 1,5 км по три раза каждый, то есть всего в 6 этапов. Соревнования начинаются с полуфинального раунда, где в каждом забеге стартуют 10-15 команд, и первые 5 из каждого полуфинала выходят в финал. Атлеты передают эстафету в специально обозначенной зоне между кругами (на стадионе), не создавая помех участникам других команд. Схема размещения команд на старте аналогична применяемой при масс-старте «стреле». Командный спринт – одно из самых захватывающих соревнований, в течение которого часто происходит смена лидера и поддерживается высокая скорость. Победитель – команда, которая пересечет линию финиша первой после 6 этапов.\r\n\r\nВ эстафете соревнуются команды, состоящие из четырех спортсменов. Первый и второй этапы бегут классическим стилем, а третий и четвертый этапы – свободным. У женщин длина этапа составляет 5 км, у мужчин – 10 км. Эстафета начинается с общего старта. Передача эстафеты происходит в специально отмеченной зоне на стадионе, где участники касаются друг друга. Победителем становится команда, которая первая пересекает линию финиша после завершения 4-го этапа.'),
(38,4,9,1,'Спортивное оборудование','<ul>\r\n<li>Ботинки для лыжных гонок классическим стилем похожи на ботинки для бега. Ботинки для свободного стиля жестче, что обеспечивает более устойчивое положение голеностопа при беге. Крепления фиксируют ботинок спортсмена на лыжах.</li>\r\n<li>Лыжные палки для гонок классическим стилем достигают примерно уровня подмышек. Для соревнований свободным стилем используются более длинные палки, которые могут доходить до плеча или подбородка. Обычно палки делают из комбинации угле- и стекловолокна.</li>\r\n<li>Лыжи — помогают оптимально распределить вес лыжника и позволяют двигаться быстрее.</li>\r\n<li>Смазка лыж бывает двух типов – для скольжения и для держания (чтобы лыжи не проскальзывали назад при отталкивании классическим стилем). Выбор основывается на характеристиках снега, погодных условиях, влажности и других аспектах.</li>\r\n<li>Костюмы лыжников сделаны из специальной стретчевой ткани (плотной лайкры), что позволяет значительно уменьшить сопротивление воздуха при беге.</li>\r\n</ul>'),
(39,5,1,1,'Немного истории','Керлинг зародился в XVI веке в Шотландии. В него играли зимой на замёрзших прудах, болотах и озёрах. На самом древнем из найденных игровых камней — Стерлингском камне, названном в честь шотландского города Стерлинга, — значится 1511 год. В шотландском аббатстве Пейсли сохранились монастырские книги ХVI века, в которых впервые упоминается керлинг. В XVII веке появились камни для керлинга с ручками. Они имели самые разнообразные формы и размеры. В XIX столетии появились камни с закругленными краями. Похожими камнями играют и сегодня.\r\n\r\nСоревнования по керлингу впервые вошли в программу Игр в 1924 году на Олимпийских зимних играх в Шамони, однако официально они были приняты Международным олимпийским комитетом только в феврале 2006 года.\r\n\r\nНа Играх 1932, 1988 и 1992 годов керлинг был демонстрационным видом спорта.\r\n\r\nКерлинг постоянно входит в программу Олимпийских игр с 1998 года.'),
(40,5,2,1,'Керлинг в России','В России керлинг впервые появился в конце XIX века в качестве спортивного досуга для зарубежных дипломатов и предпринимателей. В своем современном виде керлинг возродился в России в 1991 году в Санкт-Петербурге в стенах Института физической культуры им. П.Ф. Лесгафта.'),
(41,5,3,1,'Керлинг как он есть','Керлинг представляет собой спортивную игру на льду, в которой участвуют две команды, в каждой из которых играют 4 спортсмена. Участники поочерёдно пускают по льду гранитные снаряды («камни») весом 19,96 кг в сторону размеченной на льду мишени («дома»). Цель игры – попасть камнем ближе к центру «дома», чем это сделал соперник.\r\n\r\nИгра состоит из 10 периодов или «эндов». В течение одного энда команда выпускает по 8 камней – каждый игрок выполняет по 2 броска, чередуясь с соперником. Игроки выполняют броски в определённом порядке, который сообщается судьям до начала игры. Первый игрок, выполняющий броски команды, называется «лид». За ним следует второй, третий («вице-скип») и, наконец, капитан команды — «скип».\r\n\r\nПосле того, как разыграны все 16 камней, производится подсчёт очков в «энде». За каждый «энд» очки получает лишь одна из команд. Учитываются только те камни, которые находятся внутри «дома». Команда получает одно очко за каждый камень, расположенный ближе к центру «дома», чем любой из камней соперника. Победитель определяется по наибольшей сумме очков во всех «эндах». В случае равенства очков после 10 «эндов» назначается дополнительный период («экстра-энд»). «Экстра-энды» проводятся до выявления победителя.\r\n\r\nНа Олимпийских играх разыгрываются 2 комплекта наград: среди мужчин и среди женщин.'),
(42,5,4,1,'Спортивное оборудование','<ul>\r\n<li>Щётка — используется для натирания («свипинга») ледовой поверхности перед движущимся камнем. В результате свипинга образуется тонкий слой воды, уменьшающий трение камня о поверхность льда, улучшая тем самым его скольжение и выпрямляя траекторию его движения. Щётки могут иметь насадки из синтетического материала, из конской или свиной щетины. Для свипинга могут использоваться также метлы из тонкой соломы, но в наши дни это происходит крайне редко.</li>\r\n<li>Ботинки для керлинга отличаются подошвами. Один ботинок имеет очень скользкую подошву, сделанную из тефлона, пластика или стали, и используется для скольжения. Другой должен иметь хорошее сцепление со льдом, и его подошва изготавливается из резины.</li>\r\n<li>Камни для керлинга традиционно производятся в Шотландии из чрезвычайно редкой и твёрдой породы гранита. Каждый камень имеет округлую форму, тщательно полируется и весит 19,96 кг.</li>\r\n<li>Площадка для керлинга имеет длину 45,72 метра и ширину не более 5 метров. На каждой стороне площадки находится мишень, или «дом».</li>\r\n</ul>'),
(43,6,1,1,'Немного истории','Фигурное катание на коньках является старейшей дисциплиной в программе Олимпийских игр. Еще в 1908 году соревнования фигуристов впервые были включены в программу Олимпийских игр в Лондоне, а в 1920 году – в программу Олимпиады в Антверпене. Начиная с Олимпийских игр 1924 года в Париже, одиночное и парное фигурное катание прочно вошло в программу Олимпийских игр.\r\n\r\nПервым в истории России олимпийским чемпионом стал Николай Панин-Коломенкин. Он выиграл золото Олимпийских игр 1908 года в Лондоне в соревновательной программе, которая называлась «специальные фигуры».\r\n\r\nВ 1976 году в олимпийскую программу были включены спортивные танцы на льду, которые до этого (в 1972 году) являлись лишь демонстрационным видом. Первыми Олимпийскими чемпионами в спортивных танцах на льду в 1976 году стали советские фигуристы Людмила Пахомова и Александр Горшков.'),
(44,6,2,1,'Фигурное катание в России','Фигурное катание на коньках начало активно развиваться в России благодаря царю Петру I. Из Европы он привез образцы коньков и даже сам придумал новый способ их крепления – прямо к сапогам. После смерти Петра Великого про это увлечение забыли на долгие годы.\r\n\r\nВ 1865 году был открыт общественный каток в Юсуповском саду на Садовой улице в Санкт-Петербурге. Этот каток, самый благоустроенный в России, с первых же дней стал центром подготовки фигуристов. 5 марта 1878 года на нем состоялись первые состязания русских фигуристов.\r\n\r\nСоветская школа фигурного катания вышла на авансцену только после Второй мировой войны. И уже в 1964 году сборная СССР праздновала первый олимпийский успех – «золото» в парном катании Людмилы Белоусовой и Олега Протопопова.\r\n\r\nСейчас фигурное катание является одной из самых популярных и любимых дисциплин в России.'),
(45,6,3,1,'Фигурное катание как оно есть','В программу Олимпийских зимних игр входят следующие соревнования по фигурному катанию: индивидуальные соревнования среди мужчин и среди женщин, соревнования в парном катании, танцы на льду, а также командные соревнования. Всего в настоящее время в программе Олимпийских зимних игр разыгрывается 5 комплектов наград.'),
(46,6,4,1,'Одиночное катание','Одиночное катание среди мужчин и женщин состоит из короткой программы, включающей в себя 7 обязательных элементов, и произвольной программы. Правильно сбалансированная произвольная программа должна включать прыжки, вращения и шаги. '),
(47,6,5,1,'Парное катание','Участники соревнований среди спортивных пар также исполняют сначала короткую программу (7 элементов), а затем произвольную программу. Среди специфических элементов – поддержки, подкрутки, выбросы, тодесы и другие. Одним из главных критериев оценки программ является унисонное (одновременное и одинаковое) исполнение движений партнерами.'),
(48,6,6,1,'Танцы на льду','Танцы на льду — единственный вид программы, где разрешено использовать музыку с вокалом, при этом танцоры должны строго придерживаться музыкального ритма и ярко выражать характер музыки.\r\n\r\nВ настоящее время соревнования в танцах на льду, так же как и в других видах фигурного катания, состоят из двух программ. Короткий танец представляет собой соединение обязательного танца, включающего одну или две серии, и предписанных элементов. Тема и ритм музыкального сопровождения определяется на сезон ISU, а длительность этого танца приблизилась к требованиям в других видах фигурного катания и составляет теперь 2 минуты 50 секунд. Произвольный танец не претерпел значительных изменений, и основой его оценки является чистота исполнения предписанных элементов в близких танцевальных позициях, унисон и умение танцоров выразить характер выбранной музыки.'),
(49,6,7,1,'Командные соревнования','В фигурном катании на коньках - это состязания лучших национальных команд. Представители одиночного катания и парного катания представляют короткую и произвольную программы; в танцах на льду - выполняют короткий и произвольный танец. В каждой команде могут быть по одной спортивной и танцевальной паре, по одному мужчине и женщине в одиночном катании.'),
(50,6,8,1,'Спортивное оборудование','<ul>\r\n<li>Ботинки из толстой, прочной кожи с дополнительной шнуровкой и широкими язычками, которые обеспечивают гибкость и одновременно жесткость в области голеностопа, обычно изготавливаются по индивидуальному заказу фигуриста.</li>\r\n<li>Лезвия из карбоновой стали с вогнутой бороздкой (желобом) по всей длине лезвия и выступом на его носовой части (зубцы), который используется для толчка при исполнении отдельных видов прыжков.</li>\r\n<li>Костюм фигуриста не должен сковывать движения, поэтому шьется из эластичных и стретчевых тканей. Костюм должен соответствовать характеру выбранной музыки и отражать идею программы.</li>\r\n<li>Стандартная ледовая площадка размером 30 х 60 метров с пластиковыми или подвижными бортами. Фигуристам необходимо очень хорошее качество льда, которое достигается при помощи ледозаливочных комбайнов. Перепад толщины льда по всей поверхности не может превышать 0,5 см.</li>\r\n</ul>'),
(51,7,1,1,'Немного истории','Впервые показательные выступления по фристайлу были включены в программу Олимпийских зимних игр в 1988 году в Калгари. В 1992 году в Альбервиле в олимпийскую программу был включен спуск по бугристому склону – могул. На Играх в Лиллехаммере 1994 года к могулу присоединился ещё один вид соревнований – акробатика, а в 2010 году на Олимпийских зимних играх в Ванкувере – ски-кросс.'),
(52,7,2,1,'Фристайл в России','В СССР фристайл пришел в 1970-х годах. Первые всесоюзные соревнования по фристайлу состоялись в феврале 1986 года в окрестностях деревни Горки в Московской области. А в 1985 году была создана самостоятельная Федерация фристайла СССР.'),
(53,7,3,1,'Фристайл как он есть','В олимпийскую программу по фристайлу включены могул, акробатика, ски-кросс, ски-хафпайп и ски-слоупстайл. Ски-хафпайп и ски-слоупстайл были добавлены в олимпийскую программу в 2011 году. В каждом виде соревнований участвуют и мужчины, и женщины. Всего во фристайле разыгрывается 10 комплектов наград'),
(54,7,4,1,'Могул','Могул представляет собой спуск по бугристому склону. Во время прохождения трассы каждый спортсмен должен совершить два прыжка с трамплинов. Победителями становятся участники, получившие за свое выступление наибольшее количество баллов. Судьи оценивают качество «обработки» бугров на трассе, качество и сложность прыжков. К сумме оценок, выставленных судьями, прибавляется оценка за скорость, определяемая по специальной формуле.'),
(55,7,5,1,'Акробатика','Соревнования по акробатике включают квалификационный и финальный этапы. В каждом из них спортсмены выполняют по два прыжка со специального трамплина. В финал проходят спортсмены, набравшие наибольшее количество баллов после двух прыжков. Очки из квалификационного раунда на финал не переносятся. Судьи оценивают каждый прыжок с точки зрения техники выполнения спортсменом отталкивания, непосредственно самого прыжка и приземления.'),
(56,7,6,1,'Ски-кросс','Соревнования по ски-кроссу состоят из квалификационного и финального раундов. В квалификационном раунде спортсмены по одному на скорость проходят трассу длиной около 1000 метров с поворотами и препятствиями. Спортсмены, показавшие лучшее время, в финальном раунде разбиваются на четвёрки и соревнуются между собой за выход в следующий этап соревнований. Двое участников, пришедших первыми, продолжают соревнования, проигравшие выбывают. Спортсмены, вышедшие в финальный заезд, разыгрывают медали.'),
(57,7,7,1,'Ски-хафпайп','Спортсмены выступают на склоне, представляющем собой полутрубу (half-pipe) на лыжах для фристайла, выполняя различные трюки - сальто, перевороты, захваты, пируэты. Формат проведения соревнований: квалификация и финал, по 2 заезда в каждом раунде. Места распределяются в соответствии с общим количеством очков в финале.'),
(58,7,8,1,'Ски-слоупстайл','Спортсмены выступают на склоне, имеющем различного рода препятствия: рейлы (rails), квотерпайпы (quarter-pipes), трамплины. Технические характеристики трассы прописаны правилами Международной федерации лыжного спорта. Формат проведения соревнований: система на выбывание с полуфиналами и финалами, по 2 заезда в каждом раунде. Лучший результат определяет победителя.'),
(59,7,9,1,'Спортивное оборудование','<ul>\r\n<li>Стандартная длина мужских лыж для могула составляет примерно 180 см, а женских – 170 см. В акробатике используются лыжи единой длины – 160 см. В ски-кроссе применяют те же лыжи, что и в супер-гиганте.</li>\r\n<li>Лыжные палки помогают спортсмену в поддержании равновесия и позволяют увеличивать скорость.</li>\r\n<li>В могуле нашивки на коленях отличаются по цвету от костюма спортсмена, чтобы судьи могли более детально рассмотреть технику выполнения элемента.</li>\r\n<li>Лыжные ботинки должны хорошо выдерживать удары при приземлении.</li>\r\n<li>Шлем сделан из прочного пластика и защищает голову спортсмена во время тренировок и соревнований.</li>\r\n</ul>'),
(60,8,1,1,'Немного истории','Впервые индивидуальные соревнования по лыжному двоеборью были включены в олимпийскую программу в 1924 году в Шамони. Командные соревнования были представлены на Олимпийских играх в Калгари в 1988 году. Тогда в команде принимали участие по три спортсмена. На Олимпийских играх 1998 г. в Нагано в каждой команде было уже по четыре спортсмена.'),
(61,8,2,1,'Лыжное двоеборье в России','19 февраля 1912 года на «Северном» трамплине под Петербургом были проведены первые в России соревнования по лыжному двоеборью – прыжки с трамплина и лыжная гонка на дистанцию 4 версты.\r\n\r\nРазвитию лыжного двоеборья в России способствовало расширение программы проведения чемпионатов мира и Олимпийских игр за счет введения в 1982 году командных соревнований с участием трех спортсменов. Соревнования включали в себя прыжки с трамплина и лыжную эстафету 3×10 км.'),
(62,8,3,1,'Лыжное двоеборье как оно есть','Лыжное двоеборье включает в себя прыжок с трамплина (1 попытка) и лыжную гонку на 10 км. В олимпийскую программу по лыжному двоеборью среди мужчин входят три вида соревнований: личное первенство с прыжком со среднего трамплина мощностью HS 105 (HS = HillSize, то есть «размер трамплина»), личное первенство с прыжком с большого трамплина мощностью HS 140 и командное первенство (по два прыжка с большого трамплина мощностью HS 140 каждого участника и эстафета 4х5 км).'),
(63,8,4,1,'Личное первенство','Соревнования по личному первенству, известные также как гонка Гундерсена, проходят в два этапа. Первый этап представляет собой прыжки с 105- или 140-метрового трамплина, где каждый участник делает одну попытку. Второй этап включает в себя гонку на 10 км. В прыжках с трамплина очки начисляются за длину прыжка и технику его выполнения. Спортсмены с наибольшим количеством очков стартуют в гонке первыми, остальные выходят на дистанцию в порядке, который соотносится с полученным ими на первом этапе результатом. Победителем гонки становится тот, кто первым пересекает финишную черту.'),
(64,8,5,1,'Командное первенство','Командное первенство похоже на личное, но в нем принимают участие команды по 4 человека. В первой части соревнований каждый спортсмен совершает по одному прыжку со 140-метрового трамплина. Баллы всех членов команды суммируются. Отрыв команды от других в 45 очков дает ей право стартовать в гонке на 1 минуту раньше остальных. Лыжная гонка проводится в формате эстафеты 4×5км. Победительницей в двоеборье становится та команда, чей спортсмен первым пересекает финишную черту.'),
(65,8,6,1,'Экипировка для прыжков на лыжах с трамплина','<ul>\r\n<li>Специализированные ботинки с высоким подъемом позволяют спортсмену сильно наклоняться вперед во время полета.</li>\r\n<li>Крепления должны быть установлены параллельно направлению движения и размещены таким образом, чтобы 57% от длины лыжи приходились на ее переднюю часть (носок крепления разделяет лыжу на заднюю и переднюю часть).</li>\r\n<li>Шнур от крепления соединяет ботинок с лыжей и не позволяет лыжам раскачиваться во время полета.</li>\r\n<li>Все части комбинезона спортсмена должны быть сделаны из одного материала и быть в определенной и контролируемой степени воздухопроницаемыми. Максимальная длина лыж для прыжков с трамплина может достигать 146% от роста спортсмена.</li>\r\n</ul>'),
(66,8,7,1,'Экипировка для лыжных гонок','<ul>\r\n<li>Задняя часть ботинка плотно прилегает к лодыжке и облегчает давление на нее при скольжении свободным стилем.</li>\r\n<li>Лыжи для гонок более узкие и легкие, чем для горнолыжного спорта. У них длинные, загнутые концы и легкий подъем посередине. В длину они могут достигать 2 метров.</li>\r\n<li>Крепления фиксируют ноги горнолыжника на лыжах.</li>\r\n<li>Лыжные палки – длинные и прямые, по высоте они могут достигать подбородка спортсмена.</li>\r\n<li>Костюмы лыжников сделаны из специальной эластичной ткани, принимающей форму тела спортсмена.</li>\r\n<li>Выбор смазки зависит от качества снега и погодных условий.</li>\r\n</ul>'),
(67,9,8,1,'Немного истории','До сих пор существует несколько мнений относительно родины хоккея на льду. Точно известно лишь, что привезли его в Северную Америку англичане. Первыми играть в хоккей на льду начали солдаты, расквартированные в канадской провинции Новая Шотландия. В 1879 году студенты монреальского университета Макгилла придумали первые правила игры и организовали соревнования по хоккею на льду.\r\n\r\nПервый официальный международный турнир среди мужских команд по хоккею на льду состоялся на Олимпийских играх 1920 года.\r\n\r\nХоккей на льду среди женщин входит в программу Олимпийских игр с 1998 года.'),
(68,9,9,1,'Хоккей на льду в России','Матчи первого чемпионата СССР по хоккею на льду были сыграны 22 декабря 1946 года в Москве, Ленинграде, Риге, Каунасе и Архангельске.\r\n\r\nВ 1954 году советские хоккеисты дебютировали на чемпионате мира и сразу стали лидерами мирового хоккея. В финальном матче сборная СССР играла против канадцев и победила со счетом 7:2. Эта победа принесла нашей команде первый титул чемпиона мира.'),
(69,9,10,1,'Хоккей как он есть','Хоккейные матчи проходят на ледовой площадке. В хоккее используется шайба, изготовленная из вулканизированной резины. Перед матчами высокого уровня шайбу замораживают для того, чтобы снизить трение о ледовую поверхность.\r\n\r\nИгра заключается в противоборстве двух команд, которые с помощью клюшек стремятся забросить шайбу в ворота соперника и не пропустить её в свои. Побеждает команда, забросившая большее количество шайб в ворота соперника.\r\n\r\nОдновременно на поле со стороны одной команды должны находиться шесть игроков: два защитника, три нападающих (левый, центральный и правый) и один вратарь. Нарушивший правила игрок удаляется с площадки на определенное время. Допускается замена вратаря на шестого полевого игрока.\r\n\r\nМатч состоит из трех 20-минутных периодов с 15-минутным перерывом после первого и второго периода. В ходе встречи по команде тренера происходят смены игровых составов.\r\n\r\nВ программе Олимпийских зимних игр различают соревнования по хоккею на льду среди мужчин и среди женщин. Всего разыгрывается 2 комплекта наград.'),
(70,9,11,1,'Спортивное оборудование и экипировка','<ul>\r\n<li>Экипировку полевого игрока составляют: клюшка, коньки, шлем, нагрудник, который защищает грудную клетку, позвоночник и плечи хоккеиста, налокотники, раковина, предназначенная для защиты паховой области от ударов шайбы и других травм, хоккейные шорты со специальными уплотнителями, предотвращающие травмы при падениях, столкновениях и ударах шайбы, защитные перчатки (краги), щитки, закрывающие колено и голень хоккеиста, и свитер, надеваемый поверх нагрудника.</li>\r\n<li>Экипировка вратаря состоит из всех вышеописанных элементов, специальной вратарской маски и ловушки – перчатки, специально сконструированной для ловли шайбы, а также щитков для отражения бросков.</li>\r\n<li>Клюшки изготовлены из дерева или другого материала, например, алюминия или пластика.</li>\r\n<li>Шайба диаметром 7.62 см должна быть изготовлена из вулканизированной резины или другого одобренного Международной федерацией хоккея на льду материала и быть, в основном, черного цвета.</li>\r\n</ul>'),
(71,11,1,1,'Немного истории','На Олимпийских зимних играх 1988 года в Калгари шорт-трек был показательной дисциплиной. Лишь в 1992 году в Альбервиле он официально вошел в программу Олимпийских зимних игр и с тех пор является ее неотъемлемой частью. Зрителей шорт-трек привлекает скоростью и острым соперничеством между спортсменами.'),
(72,11,2,1,'Шорт-трек в России','В феврале 1985 года в программе соревнований Всемирной универсиады, проходившей в Италии, классические дистанции скоростного бега на коньках были заменены на бег по короткой дорожке.\r\n\r\nВ апреле 1986 года в Чемпионате мира по шорт-треку во французском Шамони впервые приняла участие советская команда. Со временем популярность этой дисциплины в России стала расти. В Москве и Санкт-Петербурге открылись центры мастеров шорт-трека.'),
(73,11,3,1,'Шорт-трек как он есть','Шорт-трек – вид скоростного бега на коньках, где спортсменам необходимо максимально быстро преодолеть соревновательную дистанцию по овальной ледовой дорожке длиной 111,12 м.\r\n\r\nВ программу олимпийских соревнований входят: бег на 500 м, 1000 м и 1500 м (среди мужчин и женщин), эстафетная гонка на 3000 м (женщины) и 5000 м (мужчины). Всего разыгрывается 8 комплектов наград.\r\n\r\nВ шорт-треке спортсмены соревнуются по системе «на выбывание». Во время массового старта спортсмены используют различные тактики, чтобы прийти к финишу первыми. Время не является решающим фактором для победы.'),
(74,11,4,1,'Индивидуальные соревнования','В индивидуальных соревнованиях принимают участие 32 спортсмена по 4 человека в каждом забеге. Из каждой четверки двое победителей выходят в следующий круг. Так продолжается до тех пор, пока не определится последняя четверка, которая и разыгрывает медали.'),
(75,11,5,1,'Эстафета','В эстафете принимают участие 8 команд по 4 спортсмена. Каждая команда может сама решать, сколько кругов будет бежать тот или иной спортсмен. Единственное исключение – это последние два круга, которые обязан бежать один и тот же конькобежец (если только он не получил травму).\r\n\r\nДве команды, показавшие лучшие результаты в полуфиналах, выходят в финал.'),
(76,11,6,1,'Спортивное оборудование','<ul>\r\n<li>Коньки для шорт-трека выше, чем классические коньки для скоростного бега. Они сделаны индивидуально для каждого спортсмена и четко фиксируют ступню и лодыжку во время бега. Лезвия коньков очень острые и длиной 40-46 см.</li>\r\n<li>Специальные жесткие перчатки для шорт-трека предохраняют руки от возможных порезов коньком.</li>\r\n<li>Шлем для шорт-трека сделан из прочного пластика и предохраняет спортсмена от травм.</li>\r\n<li>Специальный костюм для шорт-трека плотно облегает тело для уменьшения сопротивления воздуха.</li>\r\n<li>Наколенники, налокотники, а также шейные протекторы предохраняют спортсмена от травм.</li>\r\n</ul>'),
(77,12,1,1,'Немного истории','Прародителем скелетона считается спуск с гор на тобоггане – бесполозных деревянных санях, распространенных среди канадских индейцев. В литературе его появление относят к XVI веку. Сведения о спортивных состязаниях саночников датируются серединой XIX века, когда британские туристы в швейцарских Альпах начали спускаться на санях по заснеженным горным склонам.\r\n\r\nСкелетон дважды был включен в программу Олимпийских игр на своей родине, в Санкт-Морице, в 1928 и 1948 гг. Однако окончательно скелетон стал олимпийской дисциплиной в 2002 году на Играх в Солт-Лейк-Сити.'),
(78,12,2,1,'Скелетон в России','Российские спортсмены впервые приняли участие в соревнованиях по скелетону в 1994 году на этапах Кубка мира в Инсбруке и Санкт-Морице, а также на Чемпионате мира в Альтенберге. В 2002 фаворит женской сборной Екатерина Миронова заняла 7-ое место на Олимпиаде в Солт-Лейк-Сити, а в 2003 году завоевала серебряную медаль на Чемпионате мира по скелетону и установила новый рекорд трассы на разгоне. Медаль в этой дисциплине российские спортсмены завоевали впервые. В 2010 году на XXI Олимпийских зимних играх в Ванкувере российский скелетонист Александр Третьяков завоевал бронзовую медаль и стал первым призером на подобных соревнованиях среди наших соотечественников.'),
(79,12,3,1,'Скелетон как он есть','Скелетон представляет собой спуск по специальной трассе с искусственным намораживанием льда в скелетоне (санях с трубчатыми полозьями на укрепленной раме). Олимпийские соревнования по скелетону длятся два дня. Каждый спортсмен совершает по 4 заезда. Победителем становится тот, чье суммарное время (по всем 4 заездам) минимально. Если два спортсмена финишировали с одинаковым временем, они получают одинаковые награды. В программу Олимпийских зимних игр входят индивидуальные соревнования среди мужчин и женщин. Всего в скелетоне разыгрывается 2 комплекта наград.'),
(80,12,4,1,'Спортивное оборудование','<ul>\r\n<li>Сани со стальными полозьями и утяжеленной рамой без рулевого управления, на которых спортсмен лежит головой вперед по направлению движения, лицом вниз, используя для управления санями специальные шипы на ботинках.</li>\r\n<li>Перчатки для спортсменов сделаны из кожи и защищают от повреждений.</li>\r\n<li>Все спортсмены носят специальные прочные шлемы, которые защищают голову от повреждений.</li>\r\n<li>Спортивный костюм из эластичной ткани должен плотно облегать тело.</li>\r\n<li>Ботинки сделаны из синтетического материала и имеют шипы на подошвах.</li>\r\n</ul>'),
(81,13,1,1,'Немного истории','Прыжки на лыжах с трамплина входят в программу Олимпийских игр с 1924 года, когда в Шамони состоялись первые в мировой истории Олимпийские зимние игры. Прыжки с большого трамплина были включены в программу олимпийских соревнований в 1964 году на Играх в Инсбруке.'),
(82,13,2,1,'Прыжки на лыжах с трамплина в России','Первые в России любители прыжков на лыжах с самодельных снежных трамплинов заявили о себе в Петербурге и Москве в начале XX века. В 1906 году лыжники клуба «Полярная звезда» построили под Петербургом первый деревянный трамплин, с которого можно было прыгать на 10-12 м в длину. Популярность этого захватывающего спорта постепенно возрастала. Первые официальные соревнования, которые состоялись в 1912 году в местечке Юкка под Петербургом, судьи оценивали «на глазок», в основном руководствуясь общим впечатлением от прыжка.'),
(83,13,3,1,'Прыжки на лыжах с трамплина как они есть','На Олимпийских играх в Сочи в соревнованиях по прыжкам на лыжах с трамплина впервые будут участвовать женщины. В 2011 году в олимпийскую программу были добавлены индивидуальные соревнования в прыжках на лыжах со среднего трамплина среди женщин. В программу Олимпийских игр входят четыре вида соревнований: личное первенство на среднем трамплине среди мужчин и среди женщин, личное первенство на большом трамплине среди мужчин и командные соревнования среди мужчин. Всего разыгрывается 4 комплекта наград.'),
(84,13,4,1,'Личное первенство на среднем трамплине','Личное первенство на среднем трамплине представляет собой соревнование, в котором спортсмены прыгают с трамплина мощностью HS 105 м (HS = Hill Size, то есть «размер трамплина»). Длина прыжка, таким образом, может достигать 105 метров. Спортсмены выполняют два прыжка, во втором прыжке соревнуются спортсмены, показавших лучшие результаты в первом прыжке. По итогам соревнований определяется победитель, набравший максимальный балл.'),
(85,13,5,1,'Личное первенство на большом трамплине','Личное первенство на большом трамплине представляет собой соревнование, в котором спортсмены прыгают с трамплина мощностью 140 м. Соответственно, длина прыжка может достигать 140 метров или немного более. Структура соревнования и отбор победителей в этом виде такие же, как и на среднем трамплине.'),
(86,13,6,1,'Командные соревнования','Командные соревнования проходят на большом трамплине мощностью HS 140. Команды состоят из четырех человек. В финал выходят 8 команд, получивших самые высокие оценки по итогам первого прыжка. Победителем соревнования становится команда, набравшая максимальное количество баллов за все прыжки.'),
(87,13,7,1,'Спортивное оборудование','<ul>\r\n<li>Специализированные ботинки с высоким подъемом позволяют спортсмену сильно наклоняться вперед во время полета.</li>\r\n<li>Крепления должны быть установлены параллельно направлению движения и размещены таким образом, чтобы 57% от длины лыжи приходились на ее переднюю часть (крепление разделяет лыжу на переднюю и заднюю часть).</li>\r\n<li>Шнур от крепления соединяет ботинок с лыжей и не позволяет лыжам раскачиваться во время полета.</li>\r\n<li>Все части комбинезона спортсмена должны быть сделаны из одного материала и являться воздухопроницаемыми. Максимальная длина лыж для прыжков с трамплина может достигать 146% от роста спортсмена.</li>\r\n</ul>'),
(88,14,1,1,'Немного истории','На Олимпийских играх в Нагано в 1998 году сноуборд дебютировал в качестве олимпийской дисциплины. В программе значились гигантский слалом и хафпайп. Параллельный гигантский слалом появился в олимпийской программе на играх 2002 г. в Солт-Лейк-Сити. Сноуборд-кросс впервые вошел в олимпийскую программу в 2006 году в Турине.'),
(89,14,2,1,'Сноуборд в России','Первый сноуборд был завезен в Россию в конце 80-х годов XX-го века. В 2010 году российская спортсменка Екатерина Илюхина завоевала серебро в параллельном гигантском слаломе на Олимпийских зимних играх в Ванкувере.'),
(90,14,3,1,'Сноуборд как он есть','В Олимпийскую программу по сноуборду входит десять видов соревнований: хафпайп (мужчины и женщины), параллельный гигантский слалом (мужчины и женщины), сноуборд-кросс (мужчины и женщины), слоупстайл (мужчины и женщины) и параллельный слалом (мужчины и женщины). Олимпийские соревнования по параллельному слалому и слоупстайлу впервые пройдут в Сочи в 2014 году.'),
(91,14,4,1,'Хафпайп','Соревнования по хафпайпу проводятся на специальной трассе, по форме напоминающей полутрубу. Это позволяет райдерам двигаться от одной стены к другой, развивая скорость, и выполнять акробатические трюки в воздухе. Задача спортсменов – сделать как можно более сложные прыжки, продемонстрировав совершенную технику. '),
(92,14,5,1,'Параллельный гигантский слалом','В соревнованиях по параллельному гигантскому слалому двое спортсменов, стартующих одновременно, проходят параллельные трассы. По итогам квалификационного раунда в финал выходят лучшие спортсмены, которые затем соревнуются на выбывание. Победителем становится тот, кто выиграет все заезды. '),
(93,14,6,1,'Сноуборд-кросс','Трасса сноуборд-кросса состоит из разнообразных бугров, препятствий, контруклонов и трамплинов. Все участники соревнований проходят отбор в квалификационных заездах – однократном или двукратном одиночном прохождении трассы на скорость. По итогам квалификации распределяются места в финальных группах (стартовый номер 1 получает спортсмен с лучшим результатом квалификации и т. д.), где группы лидеров, одновременно проходя трассу, в динамичной борьбе разыгрывают право попасть в финал. Финальный групповой заезд определяет медалистов. '),
(94,14,7,1,'Слоупстайл','Слоупстайл. Спортсмены выступают на склоне, имеющем различного рода препятствия (рейлы, квотерпайпы, трамплины). Технические характеристики трассы прописаны правилами Международной федерации лыжного спорта. Формат проведения соревнований: система на выбывание с полуфиналами и финалами, по 2 заезда в каждом раунде. Лучший результат определяет победителя.'),
(95,14,8,1,'Параллельный слалом','Два спортсмена спускаются по параллельным трассам с установленными на них флагами синего и красного цветов. Побеждает спортсмен, прошедший дистанцию быстрее, при условии соблюдения правил прохождения трассы (траектория, штрафы и т.д.). Трассы должны максимально соответствовать друг другу по параметрам: рельеф, снежный покров, количество ворот и др.'),
(96,14,9,1,'Спортивное оборудование','<ul>\r\n<li>Специально разработанная и гибкая доска для хафпайпа и слоупстайла. Она позволяет держать равновесие и выполнять акробатические трюки.</li>\r\n<li>Доска для слалома. Она делается жесткой и узкой, что идеально подходит для крутых поворотов и высокой скорости.</li>\r\n<li>Доска для сноуборд-кросса позволяет развивать высокую скорость, а также, благодаря своей гибкости, помогает избежать ошибок при преодолении препятствий.</li>\r\n<li>Для хафпайпа, слоупстайла и сноуборд-кросса используются мягкие ботинки, а для слалома – жесткие, схожие с горнолыжными.</li>\r\n<li>Жесткий пластиковый шлем обязателен для всех спортсменов.</li>\r\n</ul>'),
(97,15,1,1,'Немного истории','Скоростной бег на коньках среди мужчин был включен в программу Олимпийских зимних игр в 1924 году. Женские соревнования впервые вошли в олимпийскую программу в 1960 году, а командная гонка преследования – лишь в 2006 году.'),
(98,15,2,1,'Скоростной бег на коньках в России','До XIX века скоростной бег на коньках был одной из любимых зимних дисциплин в России. Благодаря своей доступности и демократичности он пользовался всенародной любовью. Целые семьи приходили на Патриаршие пруды, где конькобежцы катались под аккомпанемент духового оркестра.\r\n\r\nПервый в истории России чемпионат по скоростному бегу на коньках состоялся в Москве 19 февраля 1889 г. на катке Московского речного яхт-клуба.'),
(99,15,3,1,'Скоростной бег на коньках как он есть','В скоростном беге на коньках спортсменам необходимо как можно быстрее преодолеть определенную дистанцию. Классическая длина дорожки — 400 м.\r\n\r\nПрограмма Олимпийских игр включает в себя 10 индивидуальных дистанций и 2 командные гонки преследования: мужчины соревнуются на дистанциях 500 м, 1 000 м, 1 500 м, 5 000 м, 10 000 м и в командной гонке преследования на 8 кругов; женщины соперничают на дистанциях 500м, 1 000м, 1 500м, 3 000м, 5 000м и в командной гонке преследования на 6 кругов. Таким образом, всего в скоростном беге на коньках разыгрывается 12 комплектов наград.'),
(100,15,4,1,'Индивидуальные соревнования','В индивидуальных соревнованиях в каждом забеге принимают участие 2 спортсмена, которые движутся по разным дорожкам (внутренней и внешней). На каждом круге происходит смена дорожек для того, чтобы спортсмены проходили одинаковую дистанцию. Дистанцию в 500 м спортсмены пробегают дважды (оба забега проводятся в один день). При распределении мест учитываются результаты суммарного времени двух забегов.'),
(101,15,5,1,'Командная гонка преследования','В командной гонке преследования мужчины бегут 8 кругов, а женщины – 6. В каждой гонке участвуют 2 команды по три человека. Команды в полном составе стартуют одновременно с разных сторон трека. Каждый из членов команды на какое-то время становится «ведущим» группы и бежит первым, принимая на себя сопротивление воздуха. В это время его партнеры держатся сзади. Гонка заканчивается, когда последний член команды пересекает финишную прямую.'),
(102,15,6,1,'Спортивное оборудование','<ul>\r\n<li>Для бега на льду конькобежцы используют специальную модель коньков и ботинок, которая называется «клап скейт». Ботинки конькобежцев чаще всего изготовлены из кожи кенгуру.</li>\r\n<li>Специальный обтягивающий костюм с обтягивающим капюшоном уменьшает сопротивление воздуха.</li>\r\n</ul>'),
(103,16,1,1,'Горнолыжный спорт как он есть','Горнолыжный спорт практикуется во всем мире и включает в себя семь видов соревнований: скоростной спуск, слалом, гигантский слалом, супер-гигант, супер-комбинацию, командные соревнования и недавно добавленный в программу пара-сноуборд. Спортсмены демонстрируют скорость и подвижность, совершая спуск по склону со скоростью около 100км/ч.\r\n\r\nВ соревнованиях принимают участие мужчины и женщины с разными типами инвалидности: травма позвоночника, церебральный паралич, ампутация, слепота или частичная потеря зрения и «les autres conditions» (другие виды инвалидности).\r\n\r\nУчастники делятся на три класса (стоя, сидя, слабовидящие) по степени своих функциональных возможностей. Система подсчета результатов позволяет спортсменам с различными физическими нарушениями соревноваться друг с другом.\r\n\r\nСлепых горнолыжников и спортсменов с частичной потерей зрения на дистанции сопровождают зрячие «гиды», которые дают спортсменам голосовые команды. Некоторые спортсмены используют специальное оборудование, адаптированное к их возможностям. Например, монолыжу, сидячие лыжи (sit-ski), ортопедические средства.\r\n\r\nIPC Alpine Skiing функционирует как Международная федерация по данному виду спорта, ее работа координируется Техническим комитетом МПК по горным лыжам.\r\n\r\nПаралимпийская программа включает в себя шесть видов соревнований: скоростной спуск, супер-гигант, супер-комбинацию, гигантский слалом, слалом и сноуборд, впервые включенный в Паралимпийские зимние игры 2014 года в г. Сочи.'),
(104,16,2,1,'Скоростной спуск','Каждый спортсмен совершает только один спуск. Время прохождения трассы определяет победителя гонки. В скоростном спуске длинная, крутая трасса. Спортсмены должны пройти сквозь специальные ворота. Пропуск ворот приводит к дисквалификации. В связи с плохими погодными условиями, в целях обеспечения безопасности спортсменов или по иным причинам судейская коллегия может назначить два заезда для скоростного спуска, если перепад высот не соответствует требованиям.'),
(105,16,3,1,'Слалом','Каждый спортсмен совершает два спуска на разных трассах в один день. Время прохождения дистанций суммируется, и определяется победитель соревнований. Слалом является техническим видом соревнований. Трассы в нем короче, чем в других дисциплинах, а количество ворот, которое спортсмен должен пройти, больше. Пропуск ворот приводит к дисквалификации.'),
(106,16,4,1,'Гигантский слалом','Каждый спортсмен совершает два спуска на разных трассах в один день. Время прохождения дистанций суммируется, и определяется победитель соревнований. Гигантский слалом является техническим видом соревнований. Трассы в нем длиннее, чем в слаломе, но ворот меньше. Количество ворот зависит от наклона трассы. Пропуск ворот приводит к дисквалификации.'),
(107,16,5,1,'Супер-гигант','Это скоростной вид соревнований. Каждый спортсмен совершает только один спуск. Время прохождения трассы определяет победителя гонки. Трасса в нем обычно короче, чем в скоростном спуске, но длиннее трассы для слалома и гигантского слалома.'),
(108,16,6,1,'Супер-комбинация','В супер-комбинации победитель определяется по суммарному результату двух заездов на разных трассах: первый – это обычно скоростной спуск или супер-гигант, а второй – слалом. Каждый спортсмен совершает оба спуска в один день. Время прохождения дистанций суммируется, и определяется победитель соревнований.'),
(109,16,7,1,'Сноуборд-кросс','Каждый спортсмен совершает три спуска на одной трассе. Время прохождения двух дистанций с лучшими результатами суммируется, и определяется победитель соревнований. На трассе во время спуска может находиться только один спортсмен. Соревнование проходит на искусственной трассе, включающей различные элементы рельефа, на которых можно выполнить разворот на 360 градусов, разнообразные прыжки и перекаты и т.д.'),
(110,16,8,1,'История','Горнолыжный спорт для инвалидов начал развиваться после окончания Второй мировой войны. Солдаты, вернувшиеся с войны с травмами, желали продолжать заниматься любимым спортом. В 1948 году были подготовлены первые трассы.\r\n\r\nПервые чемпионаты для лыжников с физическими нарушениями прошли в 1948 году в Бад Гаштайне (Австрия). В них приняли участие 17 спортсменов. С 1950 года соревнования проходили по всему миру. Появление сидячих лыж позволило людям, передвигающимся в колясках (параплегики и люди с ампутированными выше колен ногами), заниматься лыжами и участвовать в соревнованиях.\r\n\r\nВ программу первых Паралимпийских зимних игр, которые состоялись в 1976 году в Орнсколдсвике (Швеция), впервые вошли два вида соревнований горнолыжного спорта – слалом и гигантский слалом.\r\n\r\nСкоростной спуск был добавлен в Паралимпийскую программу в 1984 году в Инсбруке (Австрия), а супер-гигант – в 1994 году на Играх в Лиллехаммере (Норвегия). На Паралимпийских играх 1984 года в Инсбруке впервые были продемонстрированы гонки на сидячих лыжах. И уже на Паралимпийских играх 1998 года в Нагано эти соревнования вошли в официальную программу.'),
(111,17,1,1,'Биатлон как он есть','Впервые биатлон появился в программе соревнований спортсменов c физическими нарушениями во время Игр в Инсбруке в 1988 году. В 1992 году в соревнованиях стали принимать участие спортсмены с нарушениями зрения.\r\n\r\nДлина дистанции составляет 7,5 км, дистанция делится на три этапа по 2,5 км каждый. Проходя два огневых рубежа, спортсмены должны поразить мишени с расстояния 10 метров. Штраф за каждый промах назначается в виде дополнительного времени, которое добавляется к основному. Важнейшим слагаемым успеха является способность спортсмена проявить физическую выносливость и продемонстрировать точность стрельбы во время соревнования. Слепые спортсмены и спортсмены с частичной потерей зрения при стрельбе ориентируются на акустический сигнал, громкость которого возрастает по мере приближения к центру мишени. Биатлон координируется МПК и Техническим комитетом МПК по лыжным гонкам и биатлону в соответствии с адаптированными правилами Международного союза биатлонистов (IBU).'),
(112,17,2,1,'Винтовка','В паралимпийском биатлоне спортсмены могут применять любой тип пневматической винтовки или винтовки СО2 обычного вида с магазином на пять патронов в соответствии со спецификацией Правил Международного стрелкового союза (U.I.T). Спортсмены класса В (слабовидящие) используют винтовки, оснащенные электро-акустическими очками (оптроническая система).\r\n\r\nСлабовидящие спортсмены ведут стрельбу из электронной винтовки, подающей звуковой сигнал в процессе прицеливания. Чем ближе прицел к центру мишени, тем громче сигнал. Громкость сигнала позволяет стрелку обнаружить центр мишени.'),
(113,17,3,1,'Сидячие лыжи','Спортсмены с нарушениями опорно-двигательного аппарата могут участвовать в соревнованиях в положении сидя на сидячих лыжах, также называемых монолыжей. Как свидетельствует название, монолыжа снабжена креслом, которое крепится к одной лыже. Кресло оснащено ремнями и другими креплениями, а также подвеской для снижения нагрузки на тело лыжника.'),
(114,17,4,1,'Лыжи','Изготовленные из стекловолокна, лыжи для классического стиля обычно на 25-30 см превышают рост лыжника. Это узкие лыжи с изогнутыми концами, прогибом и утолщением в средней части и малым весом – каждая лыжа весит менее 0,45 кг. Лыжи для свободного стиля примерно на 10-15 см короче лыж для классического стиля для повышения маневренности. Кроме того, они жестче и имеют менее изогнутые концы. На нижней стороне лыж обоих типов находятся идущие к центру желобки для выравнивания лыж при скоростном спуске.'),
(115,17,5,1,'Мишень','В биатлоне применяются откидные металлические мишени, конструкция которых состоит из фронтальной плоскости белого цвета с пятью апертурами, за которыми расположены пять независимо функционирующих откидных мишеней с системой определения результатов стрельбы. Эта часть должна быть черного цвета. При попадании черный круг цели сменяется белым диском индикатора. Для спортсменов с частичной потерей зрения (класс В) диаметр мишени составляет 30 мм, для спортсменов с физическими нарушениями (класс LW) – 20 мм.'),
(116,17,6,1,'История','Паралимпийские зимние игры в Лиллехамере в 1994 году ознаменовались несколькими важными событиями в истории паралимпийского спорта. В качестве паралимпийского вида спорта был представлен биатлон (мужчины и женщины), а также впервые лыжные соревнования были проведены на том же объекте, на котором проводились соревнования во время Олимпийских зимних игр.'),
(117,18,1,1,'Лыжные гонки как они есть','Лыжные гонки впервые были проведены на Паралимпийских зимних играх, которые прошли в 1976 году в Орнсколддсвике (Швеция). В данных соревнованиях могут участвовать спортсмены с физическими нарушениями и нарушениями зрения/слепотой. В зависимости от типа физического нарушения, спортсмены могут участвовать в соревнованиях на сидячих лыжах (sit-ski), колясках с лыжами. Спортсмены с нарушениями зрения/слепотой участвуют в соревнованиях вместе со зрячими «гидами». Мужчины и женщины соревнуются на коротких, средних и длинных дистанциях (от 2,5 до 20 км) или участвуют в командной эстафете в классическом или свободном стиле. Лыжные гонки координируются МПК и Техническим комитетом МПК по лыжным гонкам и биатлону в соответствии с адаптированными правилами Международной федерации лыжного спорта (FIS). В соревнованиях по этому виду спорта участвуют спортсмены из 24 стран.'),
(118,18,2,1,'Сидячие лыжи','спортсмены с нарушениями опорно-двигательного аппарата могут участвовать в соревнованиях в положении сидя на сидячих лыжах, также называемых монолыжей. Как свидетельствует название, монолыжа снабжена креслом, которое крепится к одной лыже. Кресло оснащено ремнями и другими креплениями, а также подвеской для снижения нагрузки на тело лыжника.'),
(119,18,3,1,'Лыжи','Изготовленные из стекловолокна, лыжи для классического стиля обычно на 25-30 см превышают рост лыжника. Это узкие лыжи с изогнутыми концами, прогибом и утолщением в средней части и малым весом – каждая лыжа весит менее 0,45 кг. Лыжи для свободного стиля примерно на 10-15 см короче лыж для классического стиля для повышения маневренности. Кроме того, они жестче и имеют менее изогнутые концы. На нижней стороне лыж обоих типов находятся идущие к центру желобки для выравнивания лыж при скоростном спуске.'),
(120,18,4,1,'История','Соревнования по лыжным гонкам впервые были проведены на первых Паралимпийских зимних играх, которые прошли в 1976 году в Орнсколддсвике (Швеция). Мужчины и женщины соревновались на всех дистанциях лыжных гонок в классическом стиле вплоть до Паралимпийских зимних игр 1984 года в Инсбруке, на которых спортсмены впервые применили коньковый ход. С того времени соревнования были разделены на две отдельные гонки: классическим и свободным стилем. Новый стиль, тем не менее, начал официально использоваться на гонках с розыгрышем медалей лишь в 1992 году на играх в Альбервиле (Франция).\r\n\r\nПаралимпийские зимние игры в Лиллехамере в 1994 году ознаменовались несколькими важными событиями в истории паралимпийского лыжного спорта. В качестве Паралимпийского вида спорта был представлен биатлон (мужчины и женщины), а также впервые лыжные соревнования были проведены на том же объекте, на котором проводились соревнования во время Олимпийских зимних игр.'),
(121,19,1,1,'Следж хоккей как он есть','После своего дебюта на Олимпийских зимних играх в Лиллехаммере в 1994 году Паралимпийский вариант хоккея на льду быстро стал одним из самых привлекательных для болельщиков зрелищ. Это динамичная, требующая прекрасной физической подготовки игра, в которой участвуют спортсмены-мужчины с инвалидностью нижней части тела. Координирование этого вида спорта осуществляет МПК при содействии технического комитета МПК по хоккею на льду, в соответствии с правилами Международной федерации хоккея с шайбой (IIHF) с некоторыми изменениями. Вместо коньков игроки используют сани с двумя полозьями, позволяющие шайбе проскальзывать под ними. Игроки пользуются двумя клюшками: с зубьями на одном конце для отталкивания и крюком на другом для действий с шайбой.'),
(122,19,2,1,'Описание соревнований','Как и в хоккее на льду, каждая команда старается опередить своего противника, направляя шайбу по льду и делая броски по воротам команды противника и одновременно защищая свои ворота от гола со стороны противника. Одновременно на льду находятся по шесть игроков от каждой команды, включая вратаря.\r\n\r\nСани с двумя полозьями, позволяющие шайбе проскальзывать под ними, заменяют коньки, игроки используют клюшки с зубьями на одном конце и крюком на другом. Благодаря такой клюшке игроки могут быстрым движением запястья продвигать себя вперед при помощи зубьев и затем манипулировать шайбой, используя конец клюшки с крюком. Игрок может использовать две клюшки с крюками, чтобы облегчить обращение с клюшкой и одинаково свободно производить броски шайбой обеими руками. Игры в следж-хоккее на льду состоят и трех 15-минутных периодов.'),
(123,19,3,1,'Защитная экипировка','Поскольку это силовая игра, всем игрокам необходимо носить шлем с полной защитной сеткой или маской, а также защитный воротник или нагрудник. Поощряется также ношение игроками защитных накладок, включая наплечники, щитки, налокотники и большие перчатки с накладками. Кроме того, экипировка вратаря включает щитки для ног, нагрудник, шлем со щитком и перчатку-ловушку для защиты спортсмена от шайбы, скорость полета которой составляет до 100 км/ч.'),
(124,19,4,1,'Шайба','Изготовленная из вулканизированной резины или другого одобренного материала шайба имеет толщину 2,54 см, диаметр 7,62 см и вес от 156 до 170 г.'),
(125,19,5,1,'Сани','Изготовленные из алюминия или стали сани имеют длину от 0,6 м до 1,2 м, закругленную переднюю часть, одну или две разные конструкции сиденья. Сани установлены на двух полозьях, которые обычно изготавливают из отпущенной стали, каждый из них имеет в толщину 3 мм. Высота саней должна быть такой, чтобы под ними могла свободно проходить шайба. Высота главной рамы должна составлять от 8,5 см до 9,5 см надо льдом, а длина полоза не может превышать одной трети от общей длины саней. Сани могут быть оснащены спинкой, но она при правильной посадке игрока в поперечном направлении не должна выступать дальше подмышек. Ступни, щиколотки, колени и бедра игрока закрепляются на санях ремнями.'),
(126,19,6,1,'Клюшка','В следж-хоккее игроки используют две клюшки: с деревянным крюком на одном конце (для обработки шайбы и бросков с двух рук) и зубом на другом. Максимальная длина каждой клюшки – 1 м, она изготавливается из дерева, пластмассы или сплава алюминия с титаном. Максимальная длина полоза – 25 см, за исключением полозьев вратаря, максимальная длина которых составляет 35 см. Конец клюшки с острием не должен повреждать поверхность льда или же случайно наносить уколы или порезы другим игрокам, в связи с чем применяются следующие правила:\r\n<ul>\r\n<li>Никакая часть острия или зубца не может иметь острого конца.</li>\r\n<li>Острие клюшки в любой части не должно выступать более чем на 1 см.</li>\r\n<li>На острие должно быть не менее шести зубцов, максимальная длина каждого – 4 мм.</li>\r\n<li>У вратаря допускается наличие дополнительного острия на основании клюшки. Вратарь может также использовать дополнительную клюшку с полозом или перчатку-ловушку с зубцом.</li>\r\n</ul>'),
(127,19,7,1,'История игры','Будучи прямым наследником хоккея на льду, следж-хоккей был изобретен в начале 1960-х в реабилитационном центре в Стокгольме (Швеция) группой шведов, которые, несмотря на свои физические нарушения, хотели продолжать играть в хоккей. Они видоизменили салазки или сани с металлической рамой, приспособив к ним два лезвия заданного размера от хоккейных коньков, которые позволяли шайбе проходить под ними. Используя круглые палки с велосипедными рулями в качестве клюшек, эта группа людей играла без вратарей на озере к югу от Стокгольма.\r\n\r\nДанный вид спорта прижился, и к 1969 году в Стокгольме уже была лига из пяти команд, в которую входили игроки с физическими нарушениями и физически здоровые игроки.\r\n\r\nВ том же году в Стокгольме был организован первый международный матч по следж-хоккею между местной клубной командой и командой из Осло, Норвегия.\r\n\r\nВ 1970-е годы игры между командами из этих двух стран проводились раз или два в год. Команды начали формироваться еще в нескольких странах, в том числе в Великобритании (1981 г.), Канаде (1982 г.), США (1990 г.), Эстонии и Японии (1993 г.).\r\n\r\nДве шведских национальных сборных сыграли показательный матч на первых Паралимпийских зимних играх 1976 года в Орнсколддсвике в Швеции.\r\n\r\nСледж-хоккей не был официальным паралимпийским видом спорта до Паралимпийских зимних игр 1994 года в Лиллехаммере.'),
(128,20,1,1,'Керлинг на колясках как он есть','Керлинг на колясках впервые вошел в Паралимпийскую программу в 2006 году во время Игр в Турине. Этот вид спорта представляет собой паралимпийский вариант керлинга. Керлинг и керлинг на колясках отличаются способом перемещения игроков и камня по полю. Основным отличием является отказ от свипинга – натирания ледовой поверхности перед движущимся камнем. Можно сказать, что керлинг на колясках не уступает традиционному керлингу в физической нагрузке на спортсменов, и при этом характеризуется более сложной техникой броска.\r\n\r\nКоординирование этого вида спорта осуществляет организация, ответственная за координирование керлинга, - Всемирная федерация керлинга (WCF).'),
(129,20,2,1,'Описание соревнований','В данном виде спорта могут соревноваться мужчины и женщины с физическими нарушениями функций нижней части тела, включая травмы позвоночника, церебральный паралич, рассеянный склероз и ампутацию обеих ног.\r\n\r\nКоманды состоят из спортсменов обоих полов. В соревнованиях по этому виду спорта участвуют спортсмены из 24 стран.\r\n\r\nВ соревновании участвуют две команды, подающие камень на площадку, состоящую из нескольких концентрических кругов, называемых домами. Цель состоит в том, чтобы камень был подан как можно ближе к центру кругов.\r\n\r\nКоманда, получившая максимальное количество очков, т.е. подавшая камни ближе к центру кругов по итогам восьми эндов, является победителем.'),
(130,20,3,1,'Камень','Вес камня составляет 19,96 кг.'),
(131,20,4,1,'Ручка','Каждый камень снабжен ручкой для броска камня. Игроки могут бросать камни руками или специальным экстендером, который можно присоединить к ручке камня для броска.'),
(132,20,5,1,'История','Впервые Чемпионат мира по керлингу на колясках был проведен в январе 2002 года, а в марте того же года МПК присвоил керлингу на колясках среди смешанных команд статус официального паралимпийского вида спорта.\r\n\r\nВпервые паралимпийские соревнования по этому виду спорта были проведены в Турине в 2006 году. В соревнованиях участвовали 8 команд. На Паралимпийских зимних играх в Ванкувере в 2010 году в этом виде спорта соревновались уже 10 команд.')	;
#	TC`tbl_tag`utf8_general_ci	;
CREATE TABLE `tbl_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `value` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `visible` (`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_tag`utf8_general_ci	;
INSERT INTO `tbl_tag` VALUES 
(1,'biathlon',1,'Биатлон',''),
(2,'hockey',1,'Хоккей',''),
(3,'figure-skating',1,'Фигурное катание','')	;
#	TC`tbl_task`utf8_general_ci	;
CREATE TABLE `tbl_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_type_id` int(11) NOT NULL,
  `task_stage_id` int(11) NOT NULL,
  `task_prior_id` int(11) NOT NULL,
  `create_datetime` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_type_id` (`task_type_id`),
  KEY `task_stage_id` (`task_stage_id`),
  KEY `task_prior_id` (`task_prior_id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `tbl_task_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_ibfk_4` FOREIGN KEY (`task_type_id`) REFERENCES `tbl_task_type` (`id`),
  CONSTRAINT `tbl_task_ibfk_5` FOREIGN KEY (`task_stage_id`) REFERENCES `tbl_task_stage` (`id`),
  CONSTRAINT `tbl_task_ibfk_6` FOREIGN KEY (`task_prior_id`) REFERENCES `tbl_task_prior` (`id`),
  CONSTRAINT `tbl_task_ibfk_7` FOREIGN KEY (`owner_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`tbl_task`utf8_general_ci	;
INSERT INTO `tbl_task` VALUES 
(1,2,3,5,1383261664,1383261648,'01-11-2013','03:20:48',1,1,'Sitemap','')	;
#	TC`tbl_task_comment`utf8_general_ci	;
CREATE TABLE `tbl_task_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` int(11) DEFAULT NULL,
  `task_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tbl_task_comment_ibfk_3` FOREIGN KEY (`task_id`) REFERENCES `tbl_task` (`id`),
  CONSTRAINT `tbl_task_comment_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_comment`utf8_general_ci	;
INSERT INTO `tbl_task_comment` VALUES 
(1,\N,1,1,'comment')	;
#	TC`tbl_task_fav`utf8_general_ci	;
CREATE TABLE `tbl_task_fav` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  UNIQUE KEY `id_2` (`id`,`user_id`),
  KEY `id` (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tbl_task_fav_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tbl_task` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_task_fav_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_task_prior`utf8_general_ci	;
CREATE TABLE `tbl_task_prior` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` tinyint(4) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `prior` (`prior`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_prior`utf8_general_ci	;
INSERT INTO `tbl_task_prior` VALUES 
(1,1,'Самый высокий',''),
(2,2,'Высокий',''),
(3,3,'Нормальный',''),
(4,4,'Низкий',''),
(5,5,'Самый низкий','')	;
#	TC`tbl_task_stage`utf8_general_ci	;
CREATE TABLE `tbl_task_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` tinyint(4) DEFAULT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `prior` (`prior`),
  KEY `finished` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_stage`utf8_general_ci	;
INSERT INTO `tbl_task_stage` VALUES 
(1,1,2,'Не начата',''),
(2,2,2,'Отложена',''),
(3,3,2,'В работе',''),
(4,4,1,'Исполнена',''),
(5,5,1,'Провалена',''),
(6,6,1,'Завершена',''),
(7,7,1,'Отменена','')	;
#	TC`tbl_task_type`utf8_general_ci	;
CREATE TABLE `tbl_task_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_type`utf8_general_ci	;
INSERT INTO `tbl_task_type` VALUES 
(1,'Bug',''),
(2,'Feature','')	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','admin@1000web.ru','548fe0520f05bfc6f198d5e215e663a6',1,1,'2013-07-27 16:34:43','2013-11-01 03:01:54'),
(5,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@1000web.ru','a707be1503afd9dd1a79dde620577941',0,1,'2013-08-04 18:13:17','2013-10-18 06:24:57')	;
